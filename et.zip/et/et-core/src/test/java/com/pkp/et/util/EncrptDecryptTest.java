package com.pkp.et.util;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.PropertyValueEncryptionUtils;
import org.junit.Test;

public class EncrptDecryptTest {
	@Test
	public void shouldEncrypt() {
		final StandardPBEStringEncryptor enc = new StandardPBEStringEncryptor();
		enc.setPassword("et@123");
		System.out.println(
				PropertyValueEncryptionUtils.encrypt("http://www.nseindia.com/content/historical/EQUITIES/", enc));
	}

	@Test
	public void shouldDecrypt() {
		final StandardPBEStringEncryptor enc = new StandardPBEStringEncryptor();
		enc.setPassword("test");
		System.out.println(PropertyValueEncryptionUtils.decrypt("test", enc));
	}

}
