package com.pkp.et.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;
import com.pkp.et.datatype.JSR310CustomModule;

@Component
public final class JsonMapperInitializer {

	@Autowired
	private ObjectMapper jsonMapper;

	@PostConstruct
	private void configureJsonMapper() {
		jsonMapper.registerModule(new JSR310CustomModule());
		/**
		 * Configure a Jackson {@link ObjectMapper} with the
		 * {@link Hibernate4Module} so that JPA objects are correctly serialized
		 * (e.g. lazy associations aren't automatically serialized)
		 *
		 */
		final Hibernate4Module hm = new Hibernate4Module();
		hm.configure(Hibernate4Module.Feature.FORCE_LAZY_LOADING, false);
		jsonMapper.registerModule(hm);
		jsonMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		jsonMapper.setSerializationInclusion(Include.NON_NULL);
	}
}
