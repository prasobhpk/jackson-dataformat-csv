package com.pkp.et.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NseStockQuoteResponseVO {
	private String lastUpdateTime;
	private String tradedDate;
	private List<StockQuoteVO> data;

	public String getLastUpdateTime() {
		return this.lastUpdateTime;
	}

	public void setLastUpdateTime(final String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public String getTradedDate() {
		return this.tradedDate;
	}

	public void setTradedDate(final String tradedDate) {
		this.tradedDate = tradedDate;
	}

	public List<StockQuoteVO> getData() {
		return this.data;
	}

	public void setData(final List<StockQuoteVO> data) {
		this.data = data;
	}

}
