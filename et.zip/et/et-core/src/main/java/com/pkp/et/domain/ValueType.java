package com.pkp.et.domain;

public enum ValueType {
	SINGLE_VALUED, MULTI_VALUED, JSON
}
