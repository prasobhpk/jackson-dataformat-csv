package com.pkp.et.datatype;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.MonthDay;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.Period;
import java.time.Year;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.datatype.jsr310.PackageVersion;
import com.fasterxml.jackson.datatype.jsr310.deser.DurationDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.InstantDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.JSR310StringParsableDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.OffsetTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.YearDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.YearMonthDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.DurationSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.OffsetDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.OffsetTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.YearMonthSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.YearSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.ZonedDateTimeSerializer;

public final class JSR310CustomModule extends SimpleModule {
	private static final long serialVersionUID = 1L;

	public JSR310CustomModule() {
		super(PackageVersion.VERSION);

		// first deserializers
		addDeserializer(Duration.class, DurationDeserializer.INSTANCE);
		addDeserializer(Instant.class, InstantDeserializer.INSTANT);
		addDeserializer(LocalDateTime.class, LocalDateTimeDeserializer.INSTANCE);
		addDeserializer(LocalDate.class,
				com.pkp.et.datatype.dser.LocalDateDeserializer.INSTANCE);
		addDeserializer(LocalTime.class, LocalTimeDeserializer.INSTANCE);
		addDeserializer(MonthDay.class,
				JSR310StringParsableDeserializer.MONTH_DAY);
		addDeserializer(OffsetDateTime.class,
				InstantDeserializer.OFFSET_DATE_TIME);
		addDeserializer(OffsetTime.class, OffsetTimeDeserializer.INSTANCE);
		addDeserializer(Period.class, JSR310StringParsableDeserializer.PERIOD);
		addDeserializer(Year.class, YearDeserializer.INSTANCE);
		addDeserializer(YearMonth.class, YearMonthDeserializer.INSTANCE);
		addDeserializer(ZonedDateTime.class,
				InstantDeserializer.ZONED_DATE_TIME);
		addDeserializer(ZoneId.class, JSR310StringParsableDeserializer.ZONE_ID);
		addDeserializer(ZoneOffset.class,
				JSR310StringParsableDeserializer.ZONE_OFFSET);

		// then serializers:
		addSerializer(Duration.class, DurationSerializer.INSTANCE);
		addSerializer(Instant.class, InstantSerializer.INSTANCE);
		addSerializer(LocalDateTime.class, LocalDateTimeSerializer.INSTANCE);
		addSerializer(LocalDate.class, LocalDateSerializer.INSTANCE);
		addSerializer(LocalTime.class, LocalTimeSerializer.INSTANCE);
		addSerializer(MonthDay.class, ToStringSerializer.instance);
		addSerializer(OffsetDateTime.class, OffsetDateTimeSerializer.INSTANCE);
		addSerializer(OffsetTime.class, OffsetTimeSerializer.INSTANCE);
		addSerializer(Period.class, ToStringSerializer.instance);
		addSerializer(Year.class, YearSerializer.INSTANCE);
		addSerializer(YearMonth.class, YearMonthSerializer.INSTANCE);
		addSerializer(ZonedDateTime.class, ZonedDateTimeSerializer.INSTANCE);
		addSerializer(ZoneId.class, ToStringSerializer.instance);
		addSerializer(ZoneOffset.class, ToStringSerializer.instance);
	}
}
