package com.pkp.et.domain;

public enum Roles {
	ROLE_USER, ROLE_ADMIN
}
