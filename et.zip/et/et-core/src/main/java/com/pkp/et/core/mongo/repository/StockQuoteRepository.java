package com.pkp.et.core.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.pkp.et.domain.StockQuoteVO;

public interface StockQuoteRepository extends MongoRepository<StockQuoteVO, String> {

}
