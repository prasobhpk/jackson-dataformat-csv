package com.pkp.et.core.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.pkp.et.domain.StockDetails;

public interface StockDetailsRepository extends MongoRepository<StockDetails, String> {
	/**
	 * This function gathers all StockDetails objects, only containing their
	 * symbol.
	 *
	 * @return
	 */
	@Query(value = "{}", fields = "{ 'symbol' : 1 }")
	List<StockDetails> findAllSymbols();

	List<StockDetails> findBySymbol(String symbol);
	// @Query("{ 'name' : ?0 }")
	//
	// @Query("{ 'age' : { $gt: ?0, $lt: ?1 } }")
	//
	// @Query("{ 'name' : { $regex: ?0 } }")
	// List<StockDetailsVO> findStockDetailsVOsByRegexpName(String regexp);
	//
	// List<StockDetailsVO> findByName(String name);
	//
	// List<StockDetailsVO> findByNameLikeOrderByAgeAsc(String name);
	//
	// List<StockDetailsVO> findByAgeBetween(int ageGT, int ageLT);
	//
	// List<StockDetailsVO> findByNameStartingWith(String regexp);
	//
	// List<StockDetailsVO> findByNameEndingWith(String regexp);
}
