package com.pkp.et.cache.hazelcast.job;

import java.util.ArrayList;
import java.util.Collection;

import com.pkp.et.cache.hazelcast.HazelcastMapNames;
import com.pkp.et.cache.hazelcast.predicate.StockDetailsPredicate;
import com.pkp.et.domain.StockDetails;

public class ApplyStockDetailsPredicateJob extends AbstractDistributedJob<StockDetails, Collection<StockDetails>> {

	private static final long serialVersionUID = 1L;

	private final StockDetailsPredicate dealPredicate;

	public ApplyStockDetailsPredicateJob(final HazelcastMapNames mapToQuery, final StockDetailsPredicate dealPredicate) {
		super(mapToQuery);
		this.dealPredicate = dealPredicate;
	}

	@Override
	public boolean apply(final StockDetails item) {
		return dealPredicate.apply(item);
	}

	@Override
	protected Collection<StockDetails> createReturnObject() {
		return new ArrayList<>();
	}

	@Override
	protected void addPartitionResultToReturnObject(final Collection<StockDetails> returnObject,
			final Collection<StockDetails> partitionResult) {
		returnObject.addAll(partitionResult);
	}
}
