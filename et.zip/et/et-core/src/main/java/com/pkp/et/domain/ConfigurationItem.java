package com.pkp.et.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "CONFIGURATION_ITEMS", uniqueConstraints = @UniqueConstraint(columnNames = "CONFIG_ITEM_KEY") )
public class ConfigurationItem extends BaseEntity<Long> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String configKey;
	private ValueType valueType;
	private boolean isKeyValuePair;
	private String defaultValue;
	private ConfigType configType;

	public ConfigurationItem() {

	}

	public ConfigurationItem(final String configKey, final ValueType valueType, final boolean isKeyValuePair,
			final String defaultValue, final ConfigType configType) {
		super();
		this.configKey = configKey;
		this.valueType = valueType;
		this.isKeyValuePair = isKeyValuePair;
		this.defaultValue = defaultValue;
		this.configType = configType;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// @GeneratedValue(generator = "CONFIG_ITEM_GEN", strategy =
	// GenerationType.TABLE)
	@Column(name = "CONFIG_ITEM_ID")
	public Long getId() {
		return id;
	}

	@Override
	public void setId(final Long id) {
		this.id = id;
	}

	@Column(name = "CONFIG_ITEM_KEY")
	public String getConfigKey() {
		return configKey;
	}

	public void setConfigKey(final String configKey) {
		this.configKey = configKey;
	}

	@Column(name = "CONFIG_ITEM_TYPE")
	@Enumerated(EnumType.ORDINAL)
	public ValueType getValueType() {
		return valueType;
	}

	public void setValueType(final ValueType valueType) {
		this.valueType = valueType;
	}

	@Column(name = "IS_KEY_VALUE_PAIR")
	public boolean isKeyValuePair() {
		return isKeyValuePair;
	}

	public void setKeyValuePair(final boolean isKeyValuePair) {
		this.isKeyValuePair = isKeyValuePair;
	}

	@Column(name = "DEFAULT_VALUE")
	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(final String defaultValue) {
		this.defaultValue = defaultValue;
	}

	@Column(name = "CONFIG_TYPE")
	@Enumerated(EnumType.ORDINAL)
	public ConfigType getConfigType() {
		return configType;
	}

	public void setConfigType(final ConfigType configType) {
		this.configType = configType;
	}

	@Override
	public String toString() {
		return configKey;
	}
}
