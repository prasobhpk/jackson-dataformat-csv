package com.pkp.et.core.service;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.stream.Collectors.toSet;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pkp.et.core.mongo.repository.StockDetailsRepository;
import com.pkp.et.domain.StockDetails;

@Service
public class StockDetailsService {
	private static final Logger LOG = LoggerFactory.getLogger(StockDetailsService.class);

	@Autowired
	private StockDetailsRepository stockDetailsRepository;

	public List<StockDetails> getStockDetailsForSymbols(final Set<String> symbols) {
		LOG.info("Loading  stock details from DB for symbols :{}", symbols);
		final List<StockDetails> results = newArrayList(stockDetailsRepository.findAll(symbols));
		return results;
	}

	public Set<String> getStockSymbols() {
		LOG.info("Getting all stock symbols from DB");
		final List<StockDetails> stockList = stockDetailsRepository.findAllSymbols();
		final Set<String> allSymbols = stockList.stream().map(StockDetails::getSymbol).collect(toSet());
		return allSymbols;
	}

	public StockDetails getStockDetailForSymbol(final String symbol) {
		LOG.info("Getting stock detail for symbol :[{}] from DB", symbol);
		return stockDetailsRepository.findOne(symbol);
	}

}
