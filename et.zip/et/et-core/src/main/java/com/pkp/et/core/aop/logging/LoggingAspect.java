package com.pkp.et.core.aop.logging;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pkp.et.common.ETTechnicalException;

/**
 * Aspect for logging execution of service and repository Spring components.
 */
@Aspect
public class LoggingAspect {

	private final Logger LOG = LoggerFactory.getLogger(this.getClass());

	@Pointcut("within(com.pkp.et.*.repository..*) || within(com.pkp.et.*.service..*) || within(com.pkp.et.*.rest..*)")
	public void loggingPointcut() {
	}

	@AfterThrowing(pointcut = "loggingPointcut()", throwing = "e")
	public void logAfterThrowing(final JoinPoint joinPoint, final Throwable e) {
		LOG.error("Exception in {}.{}() with cause = {}", joinPoint.getSignature().getDeclaringTypeName(),
				joinPoint.getSignature().getName(), e.getCause());
	}

	@Around("loggingPointcut()")
	public Object logAround(final ProceedingJoinPoint joinPoint) throws Throwable {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Enter: {}.{}() with argument[s] = {}", joinPoint.getSignature().getDeclaringTypeName(),
					joinPoint.getSignature().getName(), Arrays.toString(joinPoint.getArgs()));
		}
		try {
			final Object result = joinPoint.proceed();
			if (LOG.isDebugEnabled()) {
				LOG.debug("Exit: {}.{}() with result = {}", joinPoint.getSignature().getDeclaringTypeName(),
						joinPoint.getSignature().getName(), result);
			}
			return result;
		} catch (final ETTechnicalException e) {
			// log.error("Illegal argument: {} in {}.{}()",
			// Arrays.toString(joinPoint.getArgs()),
			// joinPoint.getSignature().getDeclaringTypeName(),
			// joinPoint.getSignature().getName());
			throw e;
		} catch (final Exception e) {
			throw new ETTechnicalException("Server Error , Please contact admin", e);
		}
	}
}
