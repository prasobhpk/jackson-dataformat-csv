package com.pkp.et.datatype.dser;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

public class LocalDateConverter implements Converter {

	@Override
	@SuppressWarnings("unchecked")
	public boolean canConvert(final Class type) {
		return LocalDate.class.isAssignableFrom(type);
	}

	@Override
	public void marshal(final Object source, final HierarchicalStreamWriter writer, final MarshallingContext context) {
		writer.setValue(source.toString());
	}

	@Override
	@SuppressWarnings("unchecked")
	public Object unmarshal(final HierarchicalStreamReader reader, final UnmarshallingContext context) {
		return LocalDate.parse(reader.getValue(), DateTimeFormatter.ISO_LOCAL_DATE);
	}

}
