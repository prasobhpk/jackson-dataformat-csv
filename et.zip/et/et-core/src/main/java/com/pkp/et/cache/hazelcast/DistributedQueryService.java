// package com.pkp.et.cache.hazelcast;
//
// import java.util.HashSet;
// import java.util.Map;
// import java.util.Set;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.ExecutorService;
// import java.util.concurrent.Executors;
// import java.util.concurrent.Future;
//
// import javax.annotation.PostConstruct;
// import javax.annotation.PreDestroy;
// import javax.inject.Inject;
//
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.context.annotation.Profile;
// import org.springframework.stereotype.Service;
//
// import com.hazelcast.core.HazelcastInstance;
// import com.hazelcast.core.IExecutorService;
// import com.hazelcast.core.Member;
// import com.hazelcast.nio.serialization.HazelcastSerializationException;
// import com.pkp.et.cache.hazelcast.job.DistributedJob;
//
// @Service
// @Profile("distributedCache")
// public class DistributedQueryService {
//
// private static final Logger LOGGER =
// LoggerFactory.getLogger(DistributedQueryService.class);
//
// public static final String FULLSCAN_EXECUTOR = "FullScanExecutor";
//
// @Value("${omega.cache.threadPoolSize}")
// private Integer threadPoolSize;
//
// @Inject
// private HazelcastInstance client;
//
// private ExecutorService fullScanExecutor = null;
//
// @PostConstruct
// public void initIt() throws Exception {
// if (threadPoolSize > 0) {
// LOGGER.info("Define a FullScanExecutor with size {}.", threadPoolSize);
// this.fullScanExecutor = Executors.newFixedThreadPool(threadPoolSize);
// this.client.getUserContext().put(DistributedQueryService.FULLSCAN_EXECUTOR,
// this.fullScanExecutor);
// }
// }
//
// @PreDestroy
// public void cleanUp() throws Exception {
// if (this.fullScanExecutor != null) {
// LOGGER.info("Destroying the FullScanExecutor.");
// this.fullScanExecutor.shutdownNow();
// }
// }
//
// public <TDATA, TRESULT> Set<TRESULT> executedDistributedJob(final
// DistributedJob<TDATA, TRESULT> job) {
//
// Set<TRESULT> returnValues = new HashSet<>();
//
// try {
// final IExecutorService service =
// this.client.getExecutorService("DistributedQueryService");
// Map<Member, Future<TRESULT>> results = service.submitToAllMembers(new
// FullScanCallable<TDATA, TRESULT>(job));
//
// for (Future<TRESULT> future : results.values()) {
// returnValues.add(future.get());
// }
// }
// catch (InterruptedException | ExecutionException e) {
// LOGGER.error("interrupt while computing {}", job);
// }
// catch (HazelcastSerializationException e) {
// LOGGER.error("HazelcastSerializationException:", e);
// }
// return returnValues;
// }
// }
