package com.pkp.et.domain;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

public class AbstractDocument<T> implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private T documentId;

	public void setId(final T id) {
		documentId = id;
	}

	public T getId() {
		return documentId;
	}

}
