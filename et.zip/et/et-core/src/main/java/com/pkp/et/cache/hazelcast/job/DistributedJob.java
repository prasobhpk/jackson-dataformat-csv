package com.pkp.et.cache.hazelcast.job;

import java.io.Serializable;
import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.pkp.et.cache.hazelcast.HazelcastMapNames;

public interface DistributedJob<TDATA, TRESULT> extends Serializable {

	/**
	 * Returns true if an item should be included in the result, false
	 * otherwise.
	 * 
	 * @param item
	 *            an item of a distributed collection
	 * @return true if an item should be included in the result, false otherwise
	 * @see com.google.common.base.Predicate#apply(Object)
	 * @see com.hazelcast.query.Predicate#apply(java.util.Map.Entry)
	 */
	boolean apply(final TDATA item);

	/**
	 * Transform results before returning them to the client.
	 * 
	 * <p>
	 * Called once per cluster member per job.
	 * </p>
	 * 
	 * @param partitionResults
	 *            items included in the result.
	 * @return result of the job
	 */
	TRESULT processPartitionResults(final Collection<Future<Collection<TDATA>>> partitionResults)
			throws InterruptedException, ExecutionException;

	/**
	 * Return the map id which store the date to find.
	 * 
	 * @return The id of map to query.
	 */
	HazelcastMapNames getMapToQuery();
}
