package com.pkp.et.cache.hazelcast.predicate;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Set;

import com.hazelcast.query.Predicate;
import com.pkp.et.domain.StockDetails;

public class StockDetailsPredicate implements Predicate<String, StockDetails> {

	private static final long serialVersionUID = 1L;

	private Set<String> symbols = new HashSet<>();

	private Set<String> names = new HashSet<>();

	public StockDetailsPredicate(final Collection<String> symbols, final Set<String> names) {
		super();
		if (symbols != null) {
			this.symbols.addAll(symbols);
		}
		if (names != null) {
			this.names.addAll(names);
		}
	}

	@Override
	public boolean apply(final Entry<String, StockDetails> mapEntry) {
		final StockDetails stockDetails = mapEntry.getValue();
		return apply(stockDetails);
	}

	public boolean apply(final StockDetails stockDetails) {

		if (!isValueAccepted(names, stockDetails.getSymbol())) {
			return false;
		}

		return isValueAccepted(symbols, stockDetails.getSymbol());

	}

	private <T> boolean isValueAccepted(final Set<T> theSet, final T value) {
		if (value == null) {
			return true;
		}
		if (theSet.isEmpty()) {
			return false;
		}
		return theSet.contains(value);
	}

	@Override
	public String toString() {
		return "StockDetailsPredicate [symbols=" + symbols + ", names=" + names + "]";
	}

}
