package com.pkp.et.cache.dao.local;

import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.pkp.et.cache.dao.AbstractStockDetailsCache;
import com.pkp.et.domain.StockDetails;

public class StockDetailsCacheLocal extends AbstractStockDetailsCache {

	private static final Integer INIT_MAX_PRODUCT = 200;

	private static final ConcurrentHashMap<String, StockDetails> MAP_PRODUCT_BY_ID = new ConcurrentHashMap<>(
			INIT_MAX_PRODUCT);

	@Override
	public ConcurrentMap<String, StockDetails> getMap() {
		return MAP_PRODUCT_BY_ID;
	}

	@Override
	public void set(final String id, final StockDetails objectToStore) {
		getMap().put(id, objectToStore);
	}

	@Override
	public Map<String, StockDetails> get(final Set<String> ids) {
		final Map<String, StockDetails> result = new HashMap<String, StockDetails>(ids.size());
		for (final String id : ids) {
			result.put(id, MAP_PRODUCT_BY_ID.get(id));
		}
		return result;
	}

	@Override
	public Collection<StockDetails> getStockDetailsBySymbols(final Set<String> symbols) {
		return get(symbols).values();
	}

	@Override
	public Collection<StockDetails> getStockDetailsByName(final String name) {
		// MAP_PRODUCT_BY_ID.searchValues(1,item -> {
		// if (item.getName().equalsIgnoreCase(name)) {
		// return item;
		// }
		// return null;
		// });
		return MAP_PRODUCT_BY_ID.values().stream().filter(s -> s.getName().startsWith(name)).collect(toList());
	}

}
