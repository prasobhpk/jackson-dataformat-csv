package com.pkp.et.cache.dao;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import com.pkp.et.cache.AbstractCacheMap;
import com.pkp.et.domain.StockDetails;

public abstract class AbstractStockDetailsCache extends AbstractCacheMap<String, StockDetails> {

	public abstract Collection<StockDetails> getStockDetailsBySymbols(final Set<String> symbols);

	public abstract Collection<StockDetails> getStockDetailsByName(final String name);

	public abstract Map<String, StockDetails> get(final Set<String> symbols);

}
