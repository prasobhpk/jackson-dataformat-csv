package com.pkp.et.cache;

import java.util.Collection;

public interface Exportable<T> {

    public Collection<T> getAll();

    public void save(final T objectToSave);

    public Class<? extends T> getClassEmbedded();
}
