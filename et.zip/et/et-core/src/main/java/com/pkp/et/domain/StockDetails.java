package com.pkp.et.domain;

import java.sql.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "StockDetails")
@XStreamAlias("stockDetails")
public class StockDetails extends AbstractDocument<String> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Indexed
	private String symbol;
	@Indexed
	private String name;
	private String series;
	// @XStreamConverter(value = LocalDateConverter.class)
	// private LocalDate listingDate;
	// @XStreamOmitField
	private Date listingDate;
	private String isin;
	private int faceValue;

	@JsonProperty(value = "symbol", access = Access.READ_ONLY)
	public String getSymbol() {
		return symbol;
	}

	@JsonProperty(value = "SYMBOL", access = Access.WRITE_ONLY)
	public void setSymbol(final String symbol) {
		this.symbol = symbol;
	}

	@JsonProperty(value = "name", access = Access.READ_ONLY)
	public String getName() {
		return name;
	}

	@JsonProperty(value = "NAME OF COMPANY", access = Access.WRITE_ONLY)
	public void setName(final String name) {
		this.name = name;
	}

	@JsonProperty(value = "series", access = Access.READ_ONLY)
	public String getSeries() {
		return series;
	}

	@JsonProperty(value = "SERIES", access = Access.WRITE_ONLY)
	public void setSeries(final String series) {
		this.series = series;
	}

	// @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	// @JsonProperty(value = "listingDate", access = Access.READ_ONLY)
	// public LocalDate getListingDate() {
	// return listingDate;
	// }
	//
	// @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
	// @JsonDeserialize(using =
	// com.pkp.et.datatype.dser.LocalDateDeserializer.class)
	// @JsonProperty(value = "DATE OF LISTING", access = Access.WRITE_ONLY)
	// public void setListingDate(final LocalDate listingDate) {
	// this.listingDate = listingDate;
	// listedOn = Date.valueOf(listingDate);
	// }

	@JsonProperty(value = "isin", access = Access.READ_ONLY)
	public String getIsin() {
		return isin;
	}

	@JsonProperty(value = "ISIN NUMBER", access = Access.WRITE_ONLY)
	public void setIsin(final String isin) {
		this.isin = isin;
	}

	@JsonProperty(value = "faceValue", access = Access.READ_ONLY)
	public int getFaceValue() {
		return faceValue;
	}

	@JsonProperty(value = "FACE VALUE", access = Access.WRITE_ONLY)
	public void setFaceValue(final int faceValue) {
		this.faceValue = faceValue;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty(value = "listingDate", access = Access.READ_ONLY)
	public Date getListedOn() {
		return listingDate;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
	@JsonProperty(value = "DATE OF LISTING", access = Access.WRITE_ONLY)
	public void setListedOn(final Date listedOn) {
		listingDate = listedOn;
	}

	public String getUniqueId() {
		return symbol + "_" + series;
	}

	@Override
	public boolean equals(final Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final StockDetails other = (StockDetails) obj;

		return Objects.equal(symbol, other.symbol) && Objects.equal(series, other.series)
				&& Objects.equal(name, other.name) && Objects.equal(faceValue, other.faceValue)
				&& Objects.equal(listingDate, other.listingDate);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(symbol, series, name, faceValue, listingDate);
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).addValue(symbol).addValue(series).addValue(name).addValue(faceValue)
				.addValue(listingDate).toString();
	}
}
