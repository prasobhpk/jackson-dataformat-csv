package com.pkp.et.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "StockQuotes")
public class StockQuoteVO implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	private String id;
	private String symbol;
	private String companyName;
	private String isinCode;
	private BigDecimal faceValue;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal high52;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal low52;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal priceBand;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal pricebandupper;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal previousClose;
	@JsonProperty("open")
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal openPrice;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal lastPrice;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal change;
	@JsonProperty("pChange")
	private BigDecimal changeInPercentage;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal dayHigh;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal dayLow;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal totalBuyQuantity;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal totalSellQuantity;
	@JsonDeserialize(using = com.pkp.et.datatype.dser.BigDecimalDeserializer.class)
	private BigDecimal totalTradedValue;

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(final String symbol) {
		this.symbol = symbol;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(final String companyName) {
		this.companyName = companyName;
	}

	public String getIsinCode() {
		return isinCode;
	}

	public void setIsinCode(final String isinCode) {
		this.isinCode = isinCode;
	}

	public BigDecimal getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(final BigDecimal faceValue) {
		this.faceValue = faceValue;
	}

	public BigDecimal getHigh52() {
		return high52;
	}

	public void setHigh52(final BigDecimal high52) {
		this.high52 = high52;
	}

	public BigDecimal getLow52() {
		return low52;
	}

	public void setLow52(final BigDecimal low52) {
		this.low52 = low52;
	}

	public BigDecimal getPriceBand() {
		return priceBand;
	}

	public void setPriceBand(final BigDecimal priceBand) {
		this.priceBand = priceBand;
	}

	public BigDecimal getPricebandupper() {
		return pricebandupper;
	}

	public void setPricebandupper(final BigDecimal pricebandupper) {
		this.pricebandupper = pricebandupper;
	}

	public BigDecimal getPreviousClose() {
		return previousClose;
	}

	public void setPreviousClose(final BigDecimal previousClose) {
		this.previousClose = previousClose;
	}

	public BigDecimal getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(final BigDecimal openPrice) {
		this.openPrice = openPrice;
	}

	public BigDecimal getLastPrice() {
		return lastPrice;
	}

	public void setLastPrice(final BigDecimal lastPrice) {
		this.lastPrice = lastPrice;
	}

	public BigDecimal getChange() {
		return change;
	}

	public void setChange(final BigDecimal change) {
		this.change = change;
	}

	public BigDecimal getChangeInPercentage() {
		return changeInPercentage;
	}

	public void setChangeInPercentage(final BigDecimal changeInPercentage) {
		this.changeInPercentage = changeInPercentage;
	}

	public BigDecimal getDayHigh() {
		return dayHigh;
	}

	public void setDayHigh(final BigDecimal dayHigh) {
		this.dayHigh = dayHigh;
	}

	public BigDecimal getDayLow() {
		return dayLow;
	}

	public void setDayLow(final BigDecimal dayLow) {
		this.dayLow = dayLow;
	}

	public BigDecimal getTotalBuyQuantity() {
		return totalBuyQuantity;
	}

	public void setTotalBuyQuantity(final BigDecimal totalBuyQuantity) {
		this.totalBuyQuantity = totalBuyQuantity;
	}

	public BigDecimal getTotalSellQuantity() {
		return totalSellQuantity;
	}

	public void setTotalSellQuantity(final BigDecimal totalSellQuantity) {
		this.totalSellQuantity = totalSellQuantity;
	}

	public BigDecimal getTotalTradedValue() {
		return totalTradedValue;
	}

	public void setTotalTradedValue(final BigDecimal totalTradedValue) {
		this.totalTradedValue = totalTradedValue;
	}

	public String getId() {
		return id;
	}

	public void setId(final String id) {
		this.id = id;
	}

}
