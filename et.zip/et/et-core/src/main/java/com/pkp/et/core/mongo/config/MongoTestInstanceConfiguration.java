package com.pkp.et.core.mongo.config;

import java.io.IOException;
import java.net.ServerSocket;

import com.mongodb.Mongo;

import cz.jirutka.spring.embedmongo.EmbeddedMongoBuilder;

public class MongoTestInstanceConfiguration {

	public static Mongo mongo() throws IOException {
		System.setProperty("DB.TRACE", "true");
		return new EmbeddedMongoBuilder().version("2.6.0").bindIp("127.0.0.1").port(allocateRandomPort()).build();
	}

	public static int allocateRandomPort() {
		try {
			final ServerSocket server = new ServerSocket(0);
			final int port = server.getLocalPort();
			server.close();
			return port;
		} catch (final IOException e) {
			throw new RuntimeException("Failed to acquire a random free port", e);
		}
	}
}
