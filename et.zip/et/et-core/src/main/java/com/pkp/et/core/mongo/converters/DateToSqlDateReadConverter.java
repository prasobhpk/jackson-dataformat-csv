package com.pkp.et.core.mongo.converters;

import java.util.Date;

import org.springframework.core.convert.converter.Converter;

public class DateToSqlDateReadConverter implements Converter<Date, java.sql.Date> {
	@Override
	public java.sql.Date convert(final Date source) {
		return source == null ? null : new java.sql.Date(source.getTime());
	}

}
