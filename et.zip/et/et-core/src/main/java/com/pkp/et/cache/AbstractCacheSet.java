package com.pkp.et.cache;

import java.util.Set;

public abstract class AbstractCacheSet<OBJECT_TYPE> {

    public abstract Set<OBJECT_TYPE> getSet();

    public void clear() {
        getSet().clear();
    }

    public boolean remove(final OBJECT_TYPE id) {
        if (id == null) {
            return false;
        }
        return getSet().remove(id);
    }

    public boolean add(final OBJECT_TYPE objectToStore) {
        return getSet().add(objectToStore);
    }

    public int size() {
        return getSet().size();
    }

    public boolean contains(final OBJECT_TYPE id) {
        return getSet().contains(id);
    }
}
