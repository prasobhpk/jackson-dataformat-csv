package com.pkp.et.core.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.pkp.et.domain.MarkToMarket;

public interface MarkToMarketRepository extends MongoRepository<MarkToMarket, String> {
	// @Query(value = "{ 'symbol' : ?0,'series' : ?1,'tradeDate' : ?2 }", count
	// = true)
	// int findCountBySymbolAndSeriesAndTradeDate(String symbol, String series,
	// Date tradeDate);
}
