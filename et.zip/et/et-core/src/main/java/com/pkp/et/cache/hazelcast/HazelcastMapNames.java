package com.pkp.et.cache.hazelcast;

import com.pkp.et.common.ETTechnicalException;

public enum HazelcastMapNames {

	STOCK_DETAILS_BY_SYMBOL; //

	public static HazelcastMapNames getMapByName(final String mapName) throws ETTechnicalException {
		try {
			return HazelcastMapNames.valueOf(mapName);
		} catch (final IllegalArgumentException e) {
			throw new ETTechnicalException("No map defined with name : " + mapName, e);
		}
	}

}
