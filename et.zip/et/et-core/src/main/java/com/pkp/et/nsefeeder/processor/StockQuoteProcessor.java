package com.pkp.et.nsefeeder.processor;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newLinkedHashSet;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.RecursiveTask;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.web.client.RestTemplate;

import com.pkp.et.domain.NseStockQuoteResponseVO;
import com.pkp.et.domain.StockQuoteVO;

@Configurable
public final class StockQuoteProcessor extends RecursiveTask<List<StockQuoteVO>> {
	private static final Logger LOG = LoggerFactory.getLogger(StockQuoteProcessor.class);

	private static final String quoteUrl = "http://nseindia.com/live_market/dynaContent/live_watch/get_quote/ajaxGetQuoteJSON.jsp?symbol={symbolValues}";
	private static final long serialVersionUID = 1L;
	private List<String> stockSymbols;
	private static final int offset = 20;
	private RestTemplate restTemplate;

	public StockQuoteProcessor(final List<String> stockSymbols, final RestTemplate restTemplate) {
		this.stockSymbols = newArrayList(stockSymbols);
		this.restTemplate = restTemplate;
	}

	@Override
	protected List<StockQuoteVO> compute() {
		final Set<StockQuoteVO> results = newLinkedHashSet();
		final List<StockQuoteProcessor> tasks = newArrayList();
		if (stockSymbols == null || stockSymbols.isEmpty()) {
			return Collections.emptyList();
		}
		for (int i = 0; i < stockSymbols.size(); i += offset) {
			final List<String> listIds = stockSymbols.subList(i,
					i + offset > stockSymbols.size() ? stockSymbols.size() : i + offset);
			if (stockSymbols.size() > offset) {
				final StockQuoteProcessor subTask = new StockQuoteProcessor(listIds, restTemplate);
				subTask.fork();
				tasks.add(subTask);
			} else {

				final String symbolValues = StringUtils.join(listIds, ",");
				try {

					final NseStockQuoteResponseVO response = restTemplate.getForObject(quoteUrl,
							NseStockQuoteResponseVO.class, symbolValues);
					LOG.trace("NSE stock quote response size : {}", response.getData().size());
					results.addAll(response.getData());
				} catch (final Exception e) {
					LOG.error("Error while getting the quotes for url :{}", symbolValues);
				}
			}
		}
		addResultsFromTasks(results, tasks);
		return newArrayList(results);
	}

	private void addResultsFromTasks(final Set<StockQuoteVO> list, final List<StockQuoteProcessor> tasks) {
		for (final StockQuoteProcessor item : tasks) {
			list.addAll(item.join());
		}
	}

}
