package com.pkp.et.cache;

import java.util.Collection;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;

public abstract class AbstractCacheMap<OBJECT_ID, OBJECT_TYPE> implements Cache<OBJECT_ID, OBJECT_TYPE> {

    protected abstract ConcurrentMap<OBJECT_ID, OBJECT_TYPE> getMap();

    @Override
    public void clear() {
        getMap().clear();
    }

    @Override
    public OBJECT_TYPE get(final OBJECT_ID id) {
        return getMap().get(id);
    }

    @Override
    public boolean remove(final OBJECT_ID id) {
        if (id == null) {
            return false;
        }
        return getMap().remove(id) != null;
    }

    @Override
    public OBJECT_TYPE put(final OBJECT_ID id, final OBJECT_TYPE objectToStore) {
        return getMap().put(id, objectToStore);
    }

    @Override
    public int size() {
        return getMap().size();
    }

    @Override
    public Collection<OBJECT_TYPE> values() {
        return getMap().values();
    }

    @Override
    public Set<OBJECT_ID> keySet() {
        return getMap().keySet();
    }

    @Override
    public Set<Entry<OBJECT_ID, OBJECT_TYPE>> entrySet() {
        return getMap().entrySet();
    }

    @Override
    public boolean containsKey(final OBJECT_ID id) {
        return getMap().containsKey(id);
    }

}
