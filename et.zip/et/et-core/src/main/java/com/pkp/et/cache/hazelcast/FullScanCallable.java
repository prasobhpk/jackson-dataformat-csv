// package com.pkp.et.cache.hazelcast;
//
// import java.io.Serializable;
// import java.util.ArrayList;
// import java.util.Collection;
// import java.util.List;
// import java.util.concurrent.Callable;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.ExecutorService;
// import java.util.concurrent.Future;
//
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
//
// import com.hazelcast.core.HazelcastException;
// import com.hazelcast.core.HazelcastInstance;
// import com.hazelcast.core.HazelcastInstanceAware;
// import com.hazelcast.map.impl.MapService;
// import com.hazelcast.map.impl.MapServiceContext;
// import com.hazelcast.map.impl.RecordStore;
// import com.hazelcast.map.impl.proxy.MapProxyImpl;
// import com.hazelcast.map.impl.record.Record;
// import com.pkp.et.cache.hazelcast.job.DistributedJob;
//
// public class FullScanCallable<TDATA, TRESULT> implements Callable<TRESULT>,
// Serializable, HazelcastInstanceAware {
//
// private static final Logger LOGGER =
// LoggerFactory.getLogger(FullScanCallable.class);
//
// private static final long serialVersionUID = 1L;
// private transient volatile HazelcastInstance hz;
// private final DistributedJob<TDATA, TRESULT> job;
//
// public FullScanCallable(final DistributedJob<TDATA, TRESULT> job) {
// this.job = job;
// }
//
// @SuppressWarnings({ "rawtypes", "cast" })
// private MapServiceContext getMapServiceContext() {
// final MapService mapService = ((MapProxyImpl)
// hz.getMap(this.job.getMapToQuery().name())).getService();
// return mapService.getMapServiceContext();
// }
//
// @Override
// public TRESULT call() throws Exception {
//
// final ExecutorService pool = getFullScanExecutor();
// try {
// // --
// // /!\ MapService is not part of the official Hazelcast API.
// // It is used here to improve performance of full-scan.
// // OwnedPartitions is cached inside each node, and therefore
// // must be reloaded before use in case partition migration occurs.
// // --
// final MapServiceContext mapServiceContext = getMapServiceContext();
// mapServiceContext.reloadOwnedPartitions();
//
// // -- Fork a task per owned non empty record store
// final Collection<Future<Collection<TDATA>>> partitionResults = new
// ArrayList<>();
// for (final int partitionId : mapServiceContext.getOwnedPartitions()) {
// final RecordStore store = mapServiceContext.getRecordStore(partitionId,
// this.job.getMapToQuery().name());
// if (!store.isEmpty()) {
// final Future<Collection<TDATA>> result = pool.submit(() -> {
// final List<TDATA> accumulator = new ArrayList<>();
// for (final Record<TDATA> record : store.getRecordMap().values()) {
// final TDATA entryValue = record.getValue();
// final boolean match = job.apply(entryValue);
// if (match) {
// accumulator.add(entryValue);
// }
// }
// return accumulator;
// });
// partitionResults.add(result);
// }
// }
//
// // -- Join and merge
// return job.processPartitionResults(partitionResults);
// } catch (ExecutionException | InterruptedException e) {
// LOGGER.error("Failed to process request due to an exception", e);
// throw new HazelcastException(e);
// }
// }
//
// private ExecutorService getFullScanExecutor() {
// return (ExecutorService)
// this.hz.getUserContext().get(DistributedQueryService.FULLSCAN_EXECUTOR);
// }
//
// @Override
// public void setHazelcastInstance(final HazelcastInstance hazelcastInstance) {
// this.hz = hazelcastInstance;
// }
//
// }