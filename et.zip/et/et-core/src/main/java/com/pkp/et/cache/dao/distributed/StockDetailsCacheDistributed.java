package com.pkp.et.cache.dao.distributed;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;

import javax.inject.Inject;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import com.hazelcast.query.SqlPredicate;
import com.pkp.et.cache.dao.AbstractStockDetailsCache;
import com.pkp.et.cache.hazelcast.HazelcastMapNames;
import com.pkp.et.domain.StockDetails;

public class StockDetailsCacheDistributed extends AbstractStockDetailsCache {

	@Inject
	private HazelcastInstance client;

	public IMap<String, StockDetails> getIMap() {
		return client.getMap(HazelcastMapNames.STOCK_DETAILS_BY_SYMBOL.name());
	}

	@Override
	public ConcurrentMap<String, StockDetails> getMap() {
		return getIMap();
	}

	@Override
	public void set(final String id, final StockDetails objectToStore) {
		getIMap().set(id, objectToStore);
	}

	@Override
	public Map<String, StockDetails> get(final Set<String> ids) {
		return getIMap().getAll(ids);
	}

	@Override
	public Collection<StockDetails> getStockDetailsBySymbols(final Set<String> symbols) {
		return get(symbols).values();
	}

	@Override
	public Collection<StockDetails> getStockDetailsByName(final String name) {
		return getIMap().values(new SqlPredicate("LIKE " + name + "%"));
	}
}
