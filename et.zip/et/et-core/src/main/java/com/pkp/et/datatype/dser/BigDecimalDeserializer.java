package com.pkp.et.datatype.dser;

import java.io.IOException;
import java.math.BigDecimal;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;

public class BigDecimalDeserializer
		extends
		com.fasterxml.jackson.databind.deser.std.NumberDeserializers.BigDecimalDeserializer {
	private static final long serialVersionUID = 1L;

	@Override
	public BigDecimal deserialize(final JsonParser jp,
			final DeserializationContext ctxt) throws IOException,
			JsonProcessingException {
		final JsonToken t = jp.getCurrentToken();
		// String is ok too, can easily convert
		if (t == JsonToken.VALUE_STRING) { // let's do implicit re-parse
			String text = jp.getText().trim();
			text = text.replaceAll(",", "");
			if (text.length() == 0) {
				return null;
			}
			if (text.contains("No Band") || text.contains("-")) {
				return null;
			}
			try {
				return new BigDecimal(text);
			} catch (final IllegalArgumentException iae) {
				throw ctxt.weirdStringException(text, this._valueClass,
						"not a valid representation");
			}
		}
		return super.deserialize(jp, ctxt);
	}
}
