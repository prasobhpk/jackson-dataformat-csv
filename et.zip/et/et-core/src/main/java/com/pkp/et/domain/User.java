package com.pkp.et.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.Valid;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
@Table(name = "USERS")
public class User extends BaseEntity<Long> implements UserDetails {

	private static final long serialVersionUID = 1L;

	private Long id;

	private String username;

	private String password;

	private Name name;

	private Date createdDate;

	// spring security

	private boolean accountNonExpired;

	private boolean enabled;
	private boolean credentialsNonExpired;
	private boolean accountNonLocked;
	private String salt;

	private List<UserAuthority> roles = new ArrayList<UserAuthority>();

	public User() {
		createdDate = new Date();
		accountNonExpired = true;
		enabled = true;
		credentialsNonExpired = true;
		accountNonLocked = true;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// @GeneratedValue(generator = "USER_GEN", strategy = GenerationType.TABLE)
	@Column(name = "USER_ID")
	public Long getId() {
		return id;
	}

	@Override
	public void setId(final Long id) {
		this.id = id;
	}

	@Override
	@NotEmpty
	@Length(min = 4, max = 9)
	@Column(name = "USER_NAME", nullable = false, length = 50, unique = true)
	public String getUsername() {
		return username;
	}

	public void setUsername(final String userName) {
		username = userName;
	}

	@Override
	@NotEmpty
	@Length(min = 4, max = 100)
	@Column(name = "PASSWORD", nullable = false, length = 100)
	public String getPassword() {
		return password;
	}

	public void setPassword(final String password) {
		this.password = password;
	}

	@Valid
	@Embedded
	public Name getName() {
		return name;
	}

	public void setName(final Name name) {
		this.name = name;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "VALID_FROM")
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(final Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	@Transient
	public Collection<GrantedAuthority> getAuthorities() {
		final Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		for (final UserAuthority a : getRoles()) {
			authorities.add(a);
		}
		return authorities;
	}

	@ManyToMany
	@JoinTable(name = "USER_AUTHORITIES", joinColumns = {
			@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID") }, inverseJoinColumns = {
					@JoinColumn(name = "AUTHORITY_ID", referencedColumnName = "AUTHORITY_ID") })
	public List<UserAuthority> getRoles() {
		return roles;
	}

	public void setRoles(final List<UserAuthority> roles) {
		this.roles = roles;
	}

	@Override
	@Column(name = "ACC_NON_EXPIRED")
	public boolean isAccountNonExpired() {

		return accountNonExpired;
	}

	public void setAccountNonExpired(final boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	@Override
	@Column(name = "ACC_NON_LOCKED")
	public boolean isAccountNonLocked() {
		return accountNonLocked;
	}

	public void setAccountNonLocked(final boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	@Override
	@Column(name = "PASSWORD_NON_EXPIRED")
	public boolean isCredentialsNonExpired() {
		return credentialsNonExpired;
	}

	public void setCredentialsNonExpired(final boolean credentialsNonExpired) {
		this.credentialsNonExpired = credentialsNonExpired;
	}

	@Override
	@Column(name = "ACTIVE")
	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(final boolean enabled) {
		this.enabled = enabled;
	}

	@Column(name = "SALT")
	public String getSalt() {
		return salt;
	}

	public void setSalt(final String salt) {
		this.salt = salt;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof User)) {
			return false;
		}

		final User user = (User) obj;

		return (id == user.id);
	}

	@Override
	public int hashCode() {
		return (username != null ? username.hashCode() : 0);
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + username + "]";
	}
}
