package com.pkp.et.datatype.dser;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.text.WordUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class LocalDateDeserializer extends
		com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer {

	private static final long serialVersionUID = 1L;
	public static final LocalDateDeserializer INSTANCE = new LocalDateDeserializer();

	private LocalDateDeserializer() {
		this(DateTimeFormatter.ISO_LOCAL_DATE);
	}

	protected LocalDateDeserializer(final DateTimeFormatter dtf) {
		super(dtf);
	}

	@Override
	protected JsonDeserializer<LocalDate> withDateFormat(
			final DateTimeFormatter dtf) {
		return new LocalDateDeserializer(dtf);
	}

	@Override
	public LocalDate deserialize(final JsonParser parser,
			final DeserializationContext context) throws IOException,
			JsonProcessingException {
		switch (parser.getCurrentToken()) {
		case START_ARRAY:
			return super.deserialize(parser, context);
		case VALUE_STRING:
			String string = parser.getText().trim();
			if (string.length() == 0) {
				return null;
			}
			string = WordUtils.capitalizeFully(string, '-');
			return LocalDate.parse(string, this._formatter);
		}

		throw context.wrongTokenException(parser, JsonToken.START_ARRAY,
				"Expected array or string.");
	}
}
