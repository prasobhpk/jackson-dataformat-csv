package com.pkp.et.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "CONFIGURATIONS", uniqueConstraints = @UniqueConstraint(columnNames = { "USER_ID", "CONFIG_ITEM_ID" }) )
public class Configuration extends BaseEntity<Long> {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private User user;
	private ConfigurationItem configItem;
	private String configItemValue;

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// @GeneratedValue(generator = "CONFIG_GEN", strategy =
	// GenerationType.TABLE)
	@Column(name = "CONFIG_ID")
	public Long getId() {
		return id;
	}

	@Override
	public void setId(final Long id) {
		this.id = id;
	}

	@ManyToOne
	@JoinColumn(name = "USER_ID")
	public User getUser() {
		return user;
	}

	public void setUser(final User user) {
		this.user = user;
	}

	@ManyToOne
	@JoinColumn(name = "CONFIG_ITEM_ID")
	public ConfigurationItem getConfigItem() {
		return configItem;
	}

	public void setConfigItem(final ConfigurationItem configItem) {
		this.configItem = configItem;
	}

	@Column(name = "CONFIG_VALUE", nullable = false)
	public String getConfigItemValue() {
		return configItemValue;
	}

	public void setConfigItemValue(final String configItemValue) {
		this.configItemValue = configItemValue;
	}

	@Override
	public String toString() {
		return configItem + "==>" + configItemValue;
	}
}
