package com.pkp.et.domain;

import java.math.BigDecimal;
import java.sql.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.google.common.base.MoreObjects;

@Document(collection = "MarkToMarkets")
public class MarkToMarket extends AbstractDocument<String> {
	private static final long serialVersionUID = 1L;
	@Indexed
	private String symbol;
	private String series;
	@DBRef
	private StockDetails underlying;
	private BigDecimal previousClose;
	private BigDecimal openPrice;
	private BigDecimal daysHigh;
	private BigDecimal daysLow;
	private BigDecimal lastTradedPrice;
	private BigDecimal closePrice;
	private Date tradeDate;
	private BigDecimal totalTradedQty;
	private BigDecimal totalTradedValue;
	private BigDecimal percentageDiff;
	private BigDecimal fiftyTwoWeekHigh;
	private BigDecimal fiftyTwoWeekLow;
	private BigDecimal changePercent;
	private BigDecimal change;

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(final String symbol) {
		this.symbol = symbol;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(final String series) {
		this.series = series;
	}

	public StockDetails getUnderlying() {
		return underlying;
	}

	public void setUnderlying(final StockDetails underlying) {
		this.underlying = underlying;
	}

	public BigDecimal getPreviousClose() {
		return previousClose;
	}

	public void setPreviousClose(final BigDecimal previousClose) {
		this.previousClose = previousClose;
	}

	public BigDecimal getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(final BigDecimal openPrice) {
		this.openPrice = openPrice;
	}

	public BigDecimal getDaysHigh() {
		return daysHigh;
	}

	public void setDaysHigh(final BigDecimal daysHigh) {
		this.daysHigh = daysHigh;
	}

	public BigDecimal getDaysLow() {
		return daysLow;
	}

	public void setDaysLow(final BigDecimal daysLow) {
		this.daysLow = daysLow;
	}

	public BigDecimal getLastTradedPrice() {
		return lastTradedPrice;
	}

	public void setLastTradedPrice(final BigDecimal lastTradedPrice) {
		this.lastTradedPrice = lastTradedPrice;
	}

	public BigDecimal getClosePrice() {
		return closePrice;
	}

	public void setClosePrice(final BigDecimal closePrice) {
		this.closePrice = closePrice;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(final Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public BigDecimal getTotalTradedQty() {
		return totalTradedQty;
	}

	public void setTotalTradedQty(final BigDecimal totalTradedQty) {
		this.totalTradedQty = totalTradedQty;
	}

	public BigDecimal getTotalTradedValue() {
		return totalTradedValue;
	}

	public void setTotalTradedValue(final BigDecimal totalTradedValue) {
		this.totalTradedValue = totalTradedValue;
	}

	public BigDecimal getPercentageDiff() {
		return percentageDiff;
	}

	public void setPercentageDiff(final BigDecimal percentageDiff) {
		this.percentageDiff = percentageDiff;
	}

	public BigDecimal getFiftyTwoWeekHigh() {
		return fiftyTwoWeekHigh;
	}

	public void setFiftyTwoWeekHigh(final BigDecimal fiftyTwoWeekHigh) {
		this.fiftyTwoWeekHigh = fiftyTwoWeekHigh;
	}

	public BigDecimal getFiftyTwoWeekLow() {
		return fiftyTwoWeekLow;
	}

	public void setFiftyTwoWeekLow(final BigDecimal fiftyTwoWeekLow) {
		this.fiftyTwoWeekLow = fiftyTwoWeekLow;
	}

	public BigDecimal getChangePercent() {
		return changePercent;
	}

	public void setChangePercent(final BigDecimal changePercent) {
		this.changePercent = changePercent;
	}

	public BigDecimal getChange() {
		return change;
	}

	public void setChange(final BigDecimal change) {
		this.change = change;
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).addValue(symbol).addValue(series).addValue(tradeDate).toString();
	}

}
