package com.pkp.et.cache.hazelcast.job;

import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.pkp.et.cache.hazelcast.HazelcastMapNames;

public abstract class AbstractDistributedJob<TDATA, TRESULT> implements DistributedJob<TDATA, TRESULT> {

	private static final long serialVersionUID = -8305849331095287214L;

	private final HazelcastMapNames mapToQuery;

	public AbstractDistributedJob(final HazelcastMapNames mapToQuery) {
		this.mapToQuery = mapToQuery;
	}

	@Override
	public HazelcastMapNames getMapToQuery() {
		return this.mapToQuery;
	}

	@Override
	public TRESULT processPartitionResults(final Collection<Future<Collection<TDATA>>> partitionResults)
			throws InterruptedException, ExecutionException {
		final TRESULT resValues = createReturnObject();
		for (final Future<Collection<TDATA>> futurePartitionResult : partitionResults) {
			final Collection<TDATA> partitionResult = futurePartitionResult.get();
			if (partitionResult != null) {
				addPartitionResultToReturnObject(resValues, partitionResult);
			}
		}
		return resValues;
	}

	protected abstract TRESULT createReturnObject();

	protected abstract void addPartitionResultToReturnObject(final TRESULT resValues,
			final Collection<TDATA> partitionResult);
}
