package com.pkp.et.cache;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public interface Cache<OBJECT_ID, OBJECT_TYPE> {

    /**
     * clear the cache content.
     */
    void clear();

    /**
     * @param id the wanted id.
     * @return the object identify by its id. Null if not exist.
     */
    OBJECT_TYPE get(final OBJECT_ID id);

    /**
     * Remove the object identify by its id.
     * 
     * @param id the wanted id.
     */
    boolean remove(final OBJECT_ID id);

    /**
     * Add an object to the cache.
     * 
     * @param id the object id.
     * @param forex the object to add.
     * @return the previous value associated with <tt>key</tt>, or <tt>null</tt> if there was no mapping for <tt>key</tt>.
     */
    OBJECT_TYPE put(final OBJECT_ID id, final OBJECT_TYPE objectToStore);

    /**
     * Add an object to the cache without returning value.
     * 
     * @param id the object id.
     * @param forex the object to add.
     */
    void set(final OBJECT_ID id, final OBJECT_TYPE objectToStore);

    int size();

    /**
     * @return the content of the cache.
     */
    Collection<OBJECT_TYPE> values();

    Set<OBJECT_ID> keySet();

    Set<Map.Entry<OBJECT_ID, OBJECT_TYPE>> entrySet();

    /**
     * Tests if the specified id is known in the cache.
     * 
     * @param id The possible id.
     * @return <tt>true</tt> if the id is known.
     * @throws NullPointerException if the specified key is null
     */
    boolean containsKey(final OBJECT_ID id);

}
