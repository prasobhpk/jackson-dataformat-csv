package com.pkp.et.domain;

public enum ConfigType {
	USER, APPLICATION
}
