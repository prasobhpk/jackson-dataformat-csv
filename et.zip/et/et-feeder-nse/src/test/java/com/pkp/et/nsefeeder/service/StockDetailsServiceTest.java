package com.pkp.et.nsefeeder.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pkp.et.core.service.StockDetailsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:config/spring/applicationContext-et-feeder-nse-test.xml" })
@ActiveProfiles("TEST")
public class StockDetailsServiceTest {
	@Autowired
	private StockDetailsService stockQuoteService;

	@Test
	public void shouldGetStockDetails() {
		final Set<String> symbols = stockQuoteService.getStockSymbols();
		assertNotNull(symbols);
		assertTrue(symbols.size() > 0);
	}
}
