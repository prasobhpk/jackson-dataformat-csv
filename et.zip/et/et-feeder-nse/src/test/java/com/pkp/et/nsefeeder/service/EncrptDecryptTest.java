package com.pkp.et.nsefeeder.service;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.PropertyValueEncryptionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:config/spring/applicationContext-et-feeder-nse-test.xml" })
@ActiveProfiles("TEST")
public class EncrptDecryptTest {
	@Autowired
	private StandardPBEStringEncryptor enc;

	@Test
	public void shouldEncrypt() {
		System.out.println(PropertyValueEncryptionUtils.encrypt("password", enc));
	}

	@Test
	public void shouldDecrypt() {
		System.out.println(PropertyValueEncryptionUtils.decrypt("ENC(N1I6zDuZNtff5Tinoog31DWCUJNZbxqO)", enc));
	}

}
