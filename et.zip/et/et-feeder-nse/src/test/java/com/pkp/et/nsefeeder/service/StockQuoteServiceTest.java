package com.pkp.et.nsefeeder.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pkp.et.core.service.StockQuoteService;
import com.pkp.et.domain.StockQuoteVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:config/spring/applicationContext-et-feeder-nse-test.xml" })
@ActiveProfiles("TEST")
public class StockQuoteServiceTest {
	@Autowired
	private StockQuoteService stockQuoteService;

	@Test
	public void shouldGetStockQuotesFromNSE() {
		final List<StockQuoteVO> stockQuotes = stockQuoteService.getStockQuotesFromNse();
		assertNotNull(stockQuotes);
		assertTrue(stockQuotes.size() > 0);
	}

}
