package com.pkp.et.nsefeeder.batch;

import java.sql.Date;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.pkp.et.domain.MarkToMarket;

public class MarkToMarketFieldSetMapper implements FieldSetMapper<MarkToMarket> {

	@Override
	public MarkToMarket mapFieldSet(final FieldSet fieldSet) throws BindException {
		final MarkToMarket mtm = new MarkToMarket();
		mtm.setSymbol(fieldSet.readString("SYMBOL"));
		mtm.setSeries(fieldSet.readString("SERIES"));
		mtm.setOpenPrice(fieldSet.readBigDecimal("OPEN"));
		mtm.setDaysHigh(fieldSet.readBigDecimal("HIGH"));
		mtm.setDaysLow(fieldSet.readBigDecimal("LOW"));
		mtm.setClosePrice(fieldSet.readBigDecimal("CLOSE"));
		mtm.setLastTradedPrice(fieldSet.readBigDecimal("LAST"));
		mtm.setPreviousClose(fieldSet.readBigDecimal("PREVCLOSE"));
		mtm.setTotalTradedQty(fieldSet.readBigDecimal("TOTTRDQTY"));
		mtm.setTotalTradedValue(fieldSet.readBigDecimal("TOTTRDVAL"));
		mtm.setTradeDate(new Date(fieldSet.readDate("TIMESTAMP", "dd-MMM-yyyy").getTime()));
		mtm.setId(mtm.getSymbol() + "-" + mtm.getSeries() + "-" + mtm.getTradeDate().toString());
		return mtm;
	}
}
