package com.pkp.et.nsefeeder.batch.task;

import static com.google.common.collect.Sets.newHashSet;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.google.common.collect.Sets;
import com.pkp.et.core.mongo.repository.StockDetailsRepository;
import com.pkp.et.domain.StockDetails;

@ManagedResource(description = "Bean to launch nse stock details synch")
public class NSEStockDetailsSyncTask {

	private static final Logger LOG = LoggerFactory.getLogger(NSEStockDetailsSyncTask.class);

	@Value("${nse.stocks.details.url.ENC}")
	private String stockListUrl;
	@Autowired
	private ObjectMapper jsonMapper;

	@Autowired
	private StockDetailsRepository stockDetailsRepository;

	@ManagedOperation(description = "Sync stock details from nse")
	public void synchStockDetails() throws IOException {
		final Set<StockDetails> stockListFromDB = newHashSet();
		final Set<StockDetails> stockListFromNSE = newHashSet();

		stockListFromDB.addAll(stockDetailsRepository.findAll());
		stockListFromNSE.addAll(fetchStockDetailsFromNse());

		final Set<StockDetails> intersectionItems = newHashSet();
		Sets.intersection(stockListFromDB, stockListFromNSE).forEach(item -> intersectionItems.add(item));
		if (intersectionItems.size() == stockListFromDB.size() && intersectionItems.size() == stockListFromNSE.size()) {
			LOG.info("All stock details are up to date");
		} else {

			if (!intersectionItems.isEmpty()) {
				LOG.info("{} items are up to date and should be excluded from processing", intersectionItems.size());
				stockListFromDB.removeAll(intersectionItems);
				stockListFromNSE.removeAll(intersectionItems);
			}

			final Map<String, StockDetails> stockListFromNSEMap = stockListFromNSE.stream()
					.collect(Collectors.toMap(StockDetails::getUniqueId, (item) -> item));

			LOG.info("Finding the outdated stock details to remove from DB");
			final Set<StockDetails> stocksToRemove = newHashSet();
			stockListFromDB.stream().forEach(outDatedItem -> {
				if (!stockListFromNSEMap.containsKey(outDatedItem.getId())) {
					stocksToRemove.add(outDatedItem);
				}
			});
			if (!stocksToRemove.isEmpty()) {
				LOG.info("Deleting {} outdated items : {}", stocksToRemove.size(), stocksToRemove);
				stockDetailsRepository.delete(stocksToRemove);
			}
			if (!stockListFromNSE.isEmpty()) {
				LOG.info("Updating {} items : {}", stockListFromNSE.size(), stockListFromNSE);
				stockDetailsRepository.save(stockListFromNSE);
			}
		}
	}

	private Set<StockDetails> fetchStockDetailsFromNse()
			throws MalformedURLException, IOException, JsonParseException, JsonMappingException {
		LOG.info("Getting stock details from NSE : {}", stockListUrl);
		Set<StockDetails> stockList;
		final URL url = new URL(stockListUrl);
		final List<Map<?, ?>> data = readObjectsFromCsv(url.openStream());
		stockList = jsonMapper.readValue(writeAsJson(data),
				jsonMapper.getTypeFactory().constructCollectionType(Set.class, StockDetails.class));
		LOG.info("Received {} stocks from NSE", stockList.size());
		stockList.stream().forEach(item -> item.setId(item.getSymbol() + "-" + item.getSeries()));
		return stockList;
	}

	private List<Map<?, ?>> readObjectsFromCsv(final InputStream inputStream) throws IOException {
		final CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
		final CsvMapper csvMapper = new CsvMapper();
		final MappingIterator<Map<?, ?>> mappingIterator = csvMapper.readerFor(Map.class).with(bootstrap)
				.readValues(inputStream);
		return mappingIterator.readAll();
	}

	private String writeAsJson(final List<Map<?, ?>> data) throws IOException {
		return jsonMapper.writeValueAsString(data);
	}
}
