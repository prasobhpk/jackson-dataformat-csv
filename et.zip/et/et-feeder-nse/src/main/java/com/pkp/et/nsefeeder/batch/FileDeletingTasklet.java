package com.pkp.et.nsefeeder.batch;

import java.io.File;
import java.io.FilenameFilter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.UnexpectedJobExecutionException;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import com.pkp.et.common.util.FileHelper;

public class FileDeletingTasklet implements Tasklet, InitializingBean {
	private static final Logger LOG = LoggerFactory.getLogger(FileDeletingTasklet.class);
	@Value("${mtm.file.repo.location}")
	String fileRepo;

	private Resource resource;

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(fileRepo, "file must be set");
	}

	@Override
	public RepeatStatus execute(final StepContribution arg0, final ChunkContext arg1) throws Exception {
		LOG.trace("Checking files");
		final File rootDir = FileHelper.createDirectory(fileRepo);

		final File[] files = rootDir.listFiles((FilenameFilter) (repo, name) -> name.endsWith(".csv"));

		if (files.length == 0) {
			LOG.trace("No file to parse");
		}

		for (final File file : files) {
			LOG.info("Deleting file : {}", file.getPath());
			final boolean deleted = file.renameTo(new File(file.getPath() + ".DONE"));
			if (!deleted) {
				LOG.warn("Could not delete file : {}", file.getPath());
				throw new UnexpectedJobExecutionException("Could not delete file " + file.getPath());
			} else {
				LOG.info("{} is deleted!", file.getPath());
			}
		}
		return RepeatStatus.FINISHED;
	}

	public Resource getResource() {
		return resource;
	}

	public void setResource(final Resource resource) {
		this.resource = resource;
	}

}
