package com.pkp.et.nsefeeder.batch.task;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.pkp.et.common.util.FileHelper;
import com.pkp.et.core.jpa.repository.ConfigurationItemRepository;
import com.pkp.et.core.util.ETConstants;
import com.pkp.et.domain.ConfigurationItem;

@ManagedResource(description = "Bean to launch a manual historical mtm files download from nse")
public class NSEMtmFilesDownloaderTask {
	private static final Logger LOG = LoggerFactory.getLogger(NSEMtmFilesDownloaderTask.class);
	private static final String[] months = new String[] { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP",
			"OCT", "NOV", "DEC" };
	@Autowired(required = true)
	ConfigurationItemRepository configurationItemRepository;

	@Value("${mtm.file.repo.location}")
	String fileRepo;

	@Value("${mtm.file.base.url}")
	String baseUrl;

	@ManagedOperation(description = "Launch a manual historical mtm files download")
	public void downloadHistoricalMtms() {

		try {
			final ConfigurationItem item = configurationItemRepository.findByConfigKey(ETConstants.NEXT_FEED_DATE_KEY);
			LOG.info("Next NSE file Feed Date is  {}", item.getDefaultValue());
			final DateTimeFormatter dtf = DateTimeFormatter.ofPattern(ETConstants.DATE_FORMAT);
			LocalDate startDate = LocalDate.parse(item.getDefaultValue(), dtf);

			final File rootDir = FileHelper.createDirectory(fileRepo);
			final LocalDate endDate = LocalDate.now();// .plusDays(1);
			while (startDate.isBefore(endDate)) {
				final String year = "" + startDate.getYear();
				String date = "" + startDate.getDayOfMonth();
				date = date.length() == 1 ? "0" + date : date;
				final String month = months[startDate.getMonthValue() - 1];
				final URL url = new URL(
						baseUrl + year + "/" + month + "/" + "cm" + date + month + year + "bhav.csv.zip");
				final URLConnection conn = url.openConnection();
				LOG.info("Downloading {}", url);
				InputStream in = null;
				try {
					final File tempFile = File.createTempFile("nseZip", null);
					tempFile.deleteOnExit();
					in = conn.getInputStream();
					final FileOutputStream out = new FileOutputStream(tempFile);
					IOUtils.copy(in, out);

					final ZipFile zipFile = new ZipFile(tempFile);
					final Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
					while (enumeration.hasMoreElements()) {
						final ZipEntry zipEntry = enumeration.nextElement();
						unzipEntry(zipFile, zipEntry, rootDir);
					}
					zipFile.close();
				} catch (final Exception e) {
					LOG.error("Error while downloading and processing mtm from nse url:{} ,error :{}",
							new Object[] { url, e.getMessage() });
				} finally {
					if (in != null) {
						in.close();
					}
					startDate = startDate.plusDays(1);
				}
			}
			item.setDefaultValue(startDate.format(dtf));
			configurationItemRepository.save(item);
		} catch (final Exception e) {
			LOG.error("Error while nse mtm download and process task", e);
		}
	}

	void unzipEntry(final ZipFile zipFile, final ZipEntry zipEntry, final File directory) throws IOException {
		FileHelper.unzipEntry(zipFile, zipEntry, directory, zipEntry.getName());
	}

}
