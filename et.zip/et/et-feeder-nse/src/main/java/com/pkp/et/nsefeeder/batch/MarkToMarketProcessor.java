package com.pkp.et.nsefeeder.batch;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.pkp.et.core.mongo.repository.MarkToMarketRepository;
import com.pkp.et.core.mongo.repository.StockDetailsRepository;
import com.pkp.et.domain.MarkToMarket;
import com.pkp.et.domain.StockDetails;

public class MarkToMarketProcessor implements ItemProcessor<MarkToMarket, MarkToMarket> {

	private static final Logger LOG = LoggerFactory.getLogger(MarkToMarketProcessor.class);
	@Autowired
	private StockDetailsRepository stockDetailsRepository;

	@Autowired
	private MarkToMarketRepository markToMarketRepository;

	@Override
	public MarkToMarket process(final MarkToMarket mtm) throws Exception {

		if (markToMarketRepository.exists(mtm.getId())) {
			LOG.warn("[MTM Processing]Skipping item as it already exists :{}-{}-{}",
					new Object[] { mtm.getSymbol(), mtm.getSeries(), mtm.getTradeDate() });
			return null;
		}

		LOG.info("MTM Processing for stock :{}", mtm);
		StockDetails stock = null;
		stock = stockDetailsRepository.findOne(mtm.getSymbol() + "-" + mtm.getSeries());
		if (stock != null) {
			mtm.setUnderlying(stock);
		} else {
			LOG.warn("Could not find  Equity for nse symbol :{} and for series :{}",
					new Object[] { mtm.getSymbol(), mtm.getSeries() });
			final List<StockDetails> stocks = stockDetailsRepository.findBySymbol(mtm.getSymbol());
			if (!stocks.isEmpty()) {
				mtm.setUnderlying(stocks.get(0));
			}
		}

		return mtm;
	}

}
