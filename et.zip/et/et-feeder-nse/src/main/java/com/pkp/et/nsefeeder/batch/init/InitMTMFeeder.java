package com.pkp.et.nsefeeder.batch.init;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pkp.et.core.jpa.repository.ConfigurationItemRepository;
import com.pkp.et.core.util.ETConstants;
import com.pkp.et.domain.ConfigType;
import com.pkp.et.domain.ConfigurationItem;
import com.pkp.et.domain.ValueType;

@Component
public class InitMTMFeeder {

	@Autowired(required = true)
	ConfigurationItemRepository configurationItemRepository;

	@PostConstruct
	public void init() {
		if (configurationItemRepository.findByConfigKey(ETConstants.NEXT_FEED_DATE_KEY) == null) {
			final ConfigurationItem item = new ConfigurationItem(ETConstants.NEXT_FEED_DATE_KEY,
					ValueType.SINGLE_VALUED, false, ETConstants.FEED_START_DATE, ConfigType.USER);
			configurationItemRepository.save(item);
		}
	}
}
