package com.pkp.et.nsefeeder.batch;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.pkp.et.nsefeeder.batch.task.NSEStockDetailsSyncTask;

public class NSEStockDetailsSyncTasklet implements Tasklet {
	@Autowired
	private NSEStockDetailsSyncTask task;

	@Override
	public RepeatStatus execute(final StepContribution contribution, final ChunkContext chunkContext) throws Exception {
		task.synchStockDetails();
		return RepeatStatus.FINISHED;
	}

}
