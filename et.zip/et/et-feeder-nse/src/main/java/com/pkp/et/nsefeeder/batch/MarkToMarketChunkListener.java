package com.pkp.et.nsefeeder.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.listener.ItemListenerSupport;
import org.springframework.batch.item.file.FlatFileParseException;

import com.pkp.et.domain.MarkToMarket;

public class MarkToMarketChunkListener extends ItemListenerSupport<MarkToMarket, MarkToMarket> {

	private static final Logger LOG = LoggerFactory.getLogger(MarkToMarketChunkListener.class);

	@Override
	public void onReadError(final Exception ex) {
		if (ex instanceof FlatFileParseException) {
			final FlatFileParseException ffpe = (FlatFileParseException) ex;
			LOG.error(String.format("Error reading data on line '%s' - data: '%s'", ffpe.getLineNumber(),
					ffpe.getInput()));
		}
	}

}
