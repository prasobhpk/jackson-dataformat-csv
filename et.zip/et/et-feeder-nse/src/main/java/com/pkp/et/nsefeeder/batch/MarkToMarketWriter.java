package com.pkp.et.nsefeeder.batch;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.pkp.et.core.mongo.repository.MarkToMarketRepository;
import com.pkp.et.domain.MarkToMarket;

public class MarkToMarketWriter implements ItemWriter<MarkToMarket> {

	private static final Logger LOG = LoggerFactory.getLogger(MarkToMarketWriter.class);
	@Autowired
	private MarkToMarketRepository markToMarketRepository;

	@Override
	public void write(final List<? extends MarkToMarket> mtms) throws Exception {
		LOG.debug("Persisting {} mtms to DB ", mtms.size());
		try {
			markToMarketRepository.save(mtms);
		} catch (final Exception e) {
			LOG.error("Error while saving mtms", e);
		}
	}
}
