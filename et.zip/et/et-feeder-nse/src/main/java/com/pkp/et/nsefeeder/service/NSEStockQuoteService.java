package com.pkp.et.nsefeeder.service;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newHashSet;
import static java.util.stream.Collectors.toSet;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.common.collect.Sets;
import com.pkp.et.core.mongo.repository.StockQuoteRepository;
import com.pkp.et.core.service.StockDetailsService;
import com.pkp.et.domain.StockQuoteVO;
import com.pkp.et.nsefeeder.processor.StockQuoteProcessor;

@Service
public class NSEStockQuoteService {
	private static final Logger LOG = LoggerFactory.getLogger(NSEStockQuoteService.class);
	@Autowired
	private StockDetailsService stockDetailsService;
	@Autowired
	private StockQuoteRepository stockQuoteRepository;
	@Autowired
	private RestTemplate restTemplate;

	public List<StockQuoteVO> getStockQuotesFromNse() {
		final List<StockQuoteVO> quotes = newArrayList();
		final Set<String> availableStockSymbols = stockDetailsService.getStockSymbols();
		if (availableStockSymbols.isEmpty()) {
			return Collections.emptyList();
		}
		LOG.info("Requesting stock quotes for {} symbols=>{}", availableStockSymbols.size(), availableStockSymbols);
		final ForkJoinPool pool = new ForkJoinPool();
		StockQuoteResponse response = processStockQuotesRequest(pool, availableStockSymbols);
		quotes.addAll(response.getQuotes());
		int tryCount = 0;
		while (response.getMissingSymbols() != null && tryCount <= 5) {
			final Set<String> missingSymbols = response.getMissingSymbols();
			response = processStockQuotesRequest(pool, missingSymbols);
			quotes.addAll(response.getQuotes());
			tryCount++;
		}

		if (response.getMissingSymbols() != null) {
			LOG.info("Requesting stock quotes for missing {} symbols individually : {} ",
					response.getMissingSymbols().size(), response.getMissingSymbols());
			for (final String symbol : response.getMissingSymbols()) {
				final StockQuoteResponse responseForSingle = processStockQuotesRequest(pool, newHashSet(symbol));
				if (!responseForSingle.getQuotes().isEmpty()) {
					LOG.info("Received stock quote for symbol : {} as a single request", symbol);
					quotes.addAll(responseForSingle.getQuotes());
				}
			}
		}
		// Shut down ForkJoinPool using the shutdown() method.
		LOG.info("Shutting down ForkJoinPool for StockQuoteProcessor");
		pool.shutdown();
		LOG.info("Recived {} quotes finally", quotes.size());
		if (quotes.size() != availableStockSymbols.size()) {
			final Set<String> finalReceivedStockQuotes = quotes.stream().map(StockQuoteVO::getSymbol).collect(toSet());
			final Set<String> finalMissingSymbols = Sets.difference(availableStockSymbols, finalReceivedStockQuotes)
					.immutableCopy();
			LOG.info("After processing still missing quotes for {} symbols : {}", finalMissingSymbols.size(),
					finalMissingSymbols);
		}
		return quotes;
	}

	private StockQuoteResponse processStockQuotesRequest(final ForkJoinPool pool,
			final Set<String> availableStockSymbols) {
		final StockQuoteProcessor processor = new StockQuoteProcessor(newArrayList(availableStockSymbols),
				restTemplate);
		pool.execute(processor);
		do {
			LOG.info("******************************************");
			LOG.info("Main: Parallelism: {}", pool.getParallelism());
			LOG.info("Main: Active Threads: {}", pool.getActiveThreadCount());
			LOG.info("Main: Task Count: {}", pool.getQueuedTaskCount());
			LOG.info("Main: Steal Count: {}", pool.getStealCount());
			LOG.info("******************************************");
			try {
				TimeUnit.SECONDS.sleep(5);
			} catch (final InterruptedException e) {
				LOG.error("Error", e);
			}
		} while ((!processor.isDone()));
		final List<StockQuoteVO> stockQuotes = processor.join();
		LOG.info("Received {} stock quotes out of {} requested", stockQuotes.size(), availableStockSymbols.size());
		Set<String> missingSymbols = null;
		if (stockQuotes.size() != availableStockSymbols.size()) {
			final Set<String> receivedStockQuotes = stockQuotes.stream().map(StockQuoteVO::getSymbol).collect(toSet());
			missingSymbols = Sets.difference(availableStockSymbols, receivedStockQuotes).immutableCopy();
			LOG.info("Could not get stock quotes for : {}", missingSymbols);
		}
		return new StockQuoteResponse(stockQuotes, missingSymbols);
	}

	public void saveStockQuotes() {
		final List<StockQuoteVO> stockQuotes = getStockQuotesFromNse();
		stockQuoteRepository.save(stockQuotes);
	}

	private static class StockQuoteResponse {
		private List<StockQuoteVO> quotes;
		private Set<String> missingSymbols;

		public StockQuoteResponse(final List<StockQuoteVO> quotes, final Set<String> missingSymbols) {
			super();
			this.quotes = quotes;
			this.missingSymbols = missingSymbols;
		}

		public List<StockQuoteVO> getQuotes() {
			return quotes;
		}

		public Set<String> getMissingSymbols() {
			return missingSymbols;
		}

	}
}
