package com.pkp.et.cache.store;

import static com.google.common.collect.Sets.newHashSet;

import java.util.Collection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.Maps;
import com.hazelcast.core.MapStore;
import com.pkp.et.core.service.StockDetailsService;
import com.pkp.et.domain.StockDetails;

public class StockDetailsStore implements MapStore<String, StockDetails> {
	private static final Logger LOGGER = LoggerFactory.getLogger(StockDetailsStore.class);
	@Autowired
	private StockDetailsService stockDetailsService;

	// private Map<String, StockDetails> stockMap;

	// @PostConstruct
	// public void init() {
	// stockMap = Maps.newHashMap();
	// stockDetailsService.getStockDetails().stream().forEach((stock) -> {
	// stockMap.put(stock.getSymbol(), stock);
	// });
	// }

	@Override
	public StockDetails load(final String symbol) {
		LOGGER.debug("load StockDetails for [{}] from db", symbol);
		return stockDetailsService.getStockDetailForSymbol(symbol);
	}

	@Override
	public Map<String, StockDetails> loadAll(final Collection<String> symbols) {
		LOGGER.debug("load all StockDetails for : {} from db ", symbols);
		final Map<String, StockDetails> map = Maps.newHashMap();
		stockDetailsService.getStockDetailsForSymbols(newHashSet(symbols)).stream().forEach((stock) -> {
			map.put(stock.getSymbol(), stock);
		});
		return map;
		// return map;
		// return Maps.uniqueIndex(stockDetailsStore.getStockDetails(), c ->
		// c.getSymbol());
	}

	@Override
	public Iterable<String> loadAllKeys() {
		LOGGER.debug("load all stock symbols");
		return stockDetailsService.getStockSymbols();
	}

	@Override
	public void delete(final String symbol) {
		LOGGER.debug("delete the stock details from db for symbol : {}", symbol);
	}

	@Override
	public void deleteAll(final Collection<String> symbols) {
		LOGGER.debug("delete all stock details from db for symbols : {}", symbols);
	}

	@Override
	public void store(final String symbol, final StockDetails stock) {
		LOGGER.debug("save the stock detail to db with symbol : {} and value : {}", new Object[] { symbol, stock });
	}

	@Override
	public void storeAll(final Map<String, StockDetails> stocks) {
		LOGGER.debug("save the stock details to db values : {}", stocks);
	}

}
