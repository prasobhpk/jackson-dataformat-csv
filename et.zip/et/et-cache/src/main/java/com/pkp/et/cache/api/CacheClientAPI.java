package com.pkp.et.cache.api;

import java.util.Collection;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.stereotype.Service;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.query.SqlPredicate;
import com.pkp.et.cache.hazelcast.HazelcastMapNames;

@Service
public class CacheClientAPI {
	@Inject
	@Named("hzClientInstance")
	private HazelcastInstance client;

	public Collection<Object> queryMap(final String mapName, final String query) {
		final HazelcastMapNames map = HazelcastMapNames.getMapByName(mapName);
		Collection<Object> results = null;
		results = client.getMap(map.name()).values(new SqlPredicate(query));
		return results;
	}

	public Object getValueFromMap(final String mapName, final String key) {
		final HazelcastMapNames map = HazelcastMapNames.getMapByName(mapName);
		return client.getMap(map.name()).get(key);
	}

}
