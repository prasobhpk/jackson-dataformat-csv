package com.pkp.et.cache.rest;

import java.util.Collection;
import java.util.Optional;

import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.pkp.et.cache.api.CacheClientAPI;
import com.pkp.et.common.ETTechnicalException;

@RestController
public class CacheAPIController {
	@Inject
	private CacheClientAPI clientApi;

	@ExceptionHandler(ETTechnicalException.class)
	public ResponseEntity<ErrorDetail> handleException(final ETTechnicalException ex) {
		return new ResponseEntity<>(new ErrorDetail(400, ex.getMessage(), ex.getLocalizedMessage()),
				HttpStatus.BAD_REQUEST);
	}

	@ResponseBody
	@RequestMapping(value = "maps/{mapName}/{key}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<Object> getValueFromMap(@PathVariable("mapName") final String mapName,
			@PathVariable("key") final String key) {
		return Optional.ofNullable(clientApi.getValueFromMap(mapName, key))
				.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@ResponseBody
	@RequestMapping(value = "maps/{mapName}", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<Collection<Object>> queryMap(@PathVariable("mapName") final String mapName,
			@RequestBody final String query) {
		final Collection<Object> values = clientApi.queryMap(mapName, query);
		return new ResponseEntity<Collection<Object>>(values, HttpStatus.OK);
	}
}
