package com.pkp.et.common.util;

import static org.mockito.Mockito.mock;

import org.jasypt.encryption.StringEncryptor;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class EncryptablePropertyPlaceholderConfigurerTest {

	private EncryptablePropertyPlaceholderConfigurer configurer;

	@Before
	public void before() {
		configurer = new EncryptablePropertyPlaceholderConfigurer(mock(StringEncryptor.class));
	}

	@Test
	public void testCensoredPassword() {
		Assert.assertEquals(EncryptablePropertyPlaceholderConfigurer.LOGGED_PASSWORD_PROPERTY_VALUE,
				configurer.censoredPassword("password", "aValue"));
		Assert.assertEquals("aValue", configurer.censoredPassword("key1", "aValue"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testCensoredPasswordFailedWhenPasswordIsNotValued() {
		configurer.censoredPassword("password",
				EncryptablePropertyPlaceholderConfigurer.LOGGED_PASSWORD_PROPERTY_VALUE);
	}
}
