package com.pkp.et.common.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FileHelperTest {

	private File tempDirectory;

	@Before
	public void before() throws IOException {
		tempDirectory = Files.createTempDirectory("et-").toFile();
	}

	@After
	public void after() throws IOException {
		FileUtils.deleteDirectory(tempDirectory);
	}

	@Test
	public void testCopyFileToDirectory() throws IOException {
		final File tempFile = File.createTempFile("et_", ".test");
		tempFile.deleteOnExit();
		FileHelper.copyFileToDirectory(tempFile, tempDirectory);
		final File createdFile = new File(tempDirectory.getAbsolutePath() + File.separator + tempFile.getName());
		assertTrue(createdFile.exists());
		assertTrue(createdFile.isFile());
	}

	@Test
	public void testCreateAndDeleteDirectory() throws IOException {
		final File createdDirectory = FileHelper
				.createDirectory(tempDirectory.getAbsolutePath() + File.separator + "etTest");
		assertTrue(createdDirectory.exists());
		assertTrue(createdDirectory.isDirectory());

		FileHelper.deleteDirectory(createdDirectory);
		assertFalse(createdDirectory.exists());
	}

	@Test
	public void testDeleteDirectory() throws IOException {
		final File createdFile = File.createTempFile("et_", ".test");
		assertTrue(createdFile.exists());
		assertTrue(createdFile.isFile());

		FileHelper.deleteQuietly(createdFile);
		assertFalse(createdFile.exists());
	}

	@Test
	public void test() throws IOException {
		final File createdFile = File.createTempFile("et_", ".test");
		FileHelper.moveFileToDirectory(createdFile, tempDirectory);

		assertFalse(createdFile.exists());

		final File copiedFile = new File(tempDirectory.getAbsolutePath() + File.separator + createdFile.getName());
		assertTrue(copiedFile.exists());
		assertTrue(copiedFile.isFile());
	}

	@Test
	public void testUnzipEntry() throws IOException {
		final File createdDirectory = FileHelper
				.createDirectory(tempDirectory.getAbsolutePath() + File.separator + "etTestUnzip");
		final URL zipFileResource = getClass().getResource("/test-data/dummyFile.zip");
		final File fileToUnzip = new File(zipFileResource.getFile());
		FileHelper.unzipFile(fileToUnzip, createdDirectory);

		final File unzippedFile = new File(createdDirectory.getAbsolutePath() + File.separator + "dummyFile.txt");
		assertTrue(unzippedFile.exists());
		assertTrue(unzippedFile.isFile());

		final String content = FileUtils.readFileToString(unzippedFile);
		assertEquals("dummy file content", content);
	}
}
