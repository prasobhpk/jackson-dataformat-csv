/**
 * 
 */
package com.pkp.et.common.util;

import java.io.Serializable;
import java.util.List;

import com.google.common.base.Function;

/**
 * Extented by component object wrapping a String object (e.g {@link PositionId}
 * ) that could not be declare {@link Embeddable} due to a bug in Envers (JIRA
 * #?) that doesn't allow to declare an association of list of embedded objects
 * (e.g {@link List}&lt;{@link PositionId}&gt;).
 * 
 */
@SuppressWarnings("serial")
public abstract class StringComponent implements Serializable, Comparable<StringComponent> {

	protected String value;

	public static final Function<StringComponent, String> toValue = new Function<StringComponent, String>() {
		@Override
		public String apply(final StringComponent input) {
			return input.getValue();
		}
	};

	@SuppressWarnings("unchecked")
	public static final <F extends StringComponent> Function<F, String> toValue(final Class<F> type) {
		return (Function<F, String>) toValue;
	}

	/**
	 * Default constructor.
	 */
	public StringComponent() {
	}

	/**
	 * Constructor.
	 * 
	 * @param value
	 *            to set
	 */
	public StringComponent(final String value) {
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(final String value) {
		this.value = value;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + (this.value == null ? 0 : this.value.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final StringComponent other = (StringComponent) obj;
		if (this.value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!this.value.equals(other.value)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(final StringComponent obj) {
		final StringComponent component = obj;
		return this.value.compareTo(component.getValue());
	}

	@Override
	public String toString() {
		return getClass().getName() + " [value=" + this.value + "]";
	}

}
