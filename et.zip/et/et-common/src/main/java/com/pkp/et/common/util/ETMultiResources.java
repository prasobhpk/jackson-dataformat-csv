package com.pkp.et.common.util;

import org.springframework.core.io.Resource;

public class ETMultiResources {

    private Resource[] locations;

    public void setLocations(final Resource[] locations) {
        this.locations = locations;
    }

    public Resource[] getLocations() {
        return this.locations;
    }

}
