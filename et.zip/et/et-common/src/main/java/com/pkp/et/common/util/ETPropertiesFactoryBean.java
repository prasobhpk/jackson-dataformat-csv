package com.pkp.et.common.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.core.io.Resource;

public class ETPropertiesFactoryBean extends PropertiesFactoryBean {

    private List<ETMultiResources> listOfLocations;

    @Override
    protected Properties createProperties() throws IOException {
        final Collection<Resource> resources = new ArrayList<Resource>();
        for (final ETMultiResources omegaResources : this.listOfLocations) {
            final Resource[] locations = omegaResources.getLocations();
            for (final Resource resource : locations) {
                resources.add(resource);
            }
        }
        setLocations(resources.toArray(new Resource[resources.size()]));
        return super.createProperties();
    }

    public void setListOfLocations(final List<ETMultiResources> listOfLocations) {
        this.listOfLocations = listOfLocations;
    }

}
