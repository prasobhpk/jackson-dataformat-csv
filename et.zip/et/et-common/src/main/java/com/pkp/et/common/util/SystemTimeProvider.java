package com.pkp.et.common.util;

import java.util.Date;

import org.joda.time.DateTime;


/**
 * A Time Provider returning the system time
 */
public class SystemTimeProvider implements TimeProvider {

	@Override
	public long getCurrentTime() {
		return System.currentTimeMillis();
	}

	@Override
	public Date getCurrentDate() {
		return new Date(getCurrentTime());
	}

	@Override
	public DateTime getCurrentDateTime() {
		return DateUtil.convertDateToDateTime(getCurrentDate());
	}
}
