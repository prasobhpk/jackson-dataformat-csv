package com.pkp.et.common.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class Timer {
	private static final Logger LOG = LoggerFactory.getLogger(Timer.class);

	public class Measure {
		public Measure(final String name, final DateTime start) {
			super();
			this.name = name;
			this.start = start;
			subMeasures = new ArrayList<Timer.Measure>();
		}

		public DateTime getStart() {
			return start;
		}

		public void setStart(final DateTime start) {
			this.start = start;
		}

		public DateTime getEnd() {
			return end;
		}

		public void setEnd(final DateTime end) {
			this.end = end;
		}

		private String name;
		private DateTime start;
		private DateTime end;
		private List<Measure> subMeasures;

		public void addSubMeasure(final Measure subMeasure) {
			subMeasures.add(subMeasure);
		}

		public void aggregateIntoMap(final HashMap<List<String>, MeasureAggregate> aggregates,
				final List<List<String>> paths, final List<String> currentPath) {
			final List<String> myPath = new ArrayList<String>();
			myPath.addAll(currentPath);
			myPath.add(name);
			if (!aggregates.containsKey(myPath)) {
				aggregates.put(myPath, new MeasureAggregate());
				paths.add(myPath);
			}
			aggregates.get(myPath).aggregateMeasure(this);
			if (!subMeasures.isEmpty()) {
				for (final Measure subMeasure : subMeasures) {
					subMeasure.aggregateIntoMap(aggregates, paths, myPath);
				}
			}
		}
	}

	public class MeasureAggregate {

		public MeasureAggregate() {
			super();
			nbMeasures = 0;
			min = null;
			max = null;
			total = 0;
		}

		private int nbMeasures;
		private Long min;
		private Long max;
		private long total;

		public void aggregateMeasure(final Measure measure) {
			nbMeasures++;
			final long measureDuration = measure.getEnd().getMillis() - measure.getStart().getMillis();
			total += measureDuration;
			if (max == null || max < measureDuration) {
				max = measureDuration;
			}
			if (min == null || min > measureDuration) {
				min = measureDuration;
			}
		}

		@Override
		public String toString() {
			return "avg: " + ((double) total / (double) nbMeasures) + "\tnb: " + nbMeasures + "\t min: " + min
					+ "\t max" + max;
		}
	}

	@Inject
	TimeProvider timeProvider;

	private HashMap<String, Stack<Measure>> timers = new HashMap<String, Stack<Measure>>();

	public void startTimer(final String timerName, final String measureName) {
		if (timers.get(timerName) == null) {
			timers.put(timerName, new Stack<Timer.Measure>());
		}
		timers.get(timerName).push(new Measure(measureName, timeProvider.getCurrentDateTime()));
	}

	public void stopTimer(final String timerName) {
		final Measure latestMeasure = timers.get(timerName).pop();
		latestMeasure.setEnd(timeProvider.getCurrentDateTime());
		if (!timers.get(timerName).isEmpty() && timers.get(timerName).peek().getEnd() == null) {
			timers.get(timerName).peek().addSubMeasure(latestMeasure);
		} else {
			timers.get(timerName).push(latestMeasure);
		}
	}

	public void stopStartTimer(final String timerName, final String measureName) {
		stopTimer(timerName);
		startTimer(timerName, measureName);
	}

	public void setTimeProvider(final TimeProvider timeProvider) {
		this.timeProvider = timeProvider;
	}

	public List<String> getStats(final String timerName) {
		final List<String> result = new ArrayList<String>();
		final HashMap<List<String>, MeasureAggregate> aggregates = new HashMap<List<String>, MeasureAggregate>();
		final List<List<String>> measuresOrder = new ArrayList<List<String>>();
		final List<String> currentPath = new ArrayList<String>();
		final Stack<Measure> reversedStack = new Stack<Timer.Measure>();
		while (!timers.get(timerName).empty()) {
			reversedStack.push(timers.get(timerName).pop());
		}
		while (!reversedStack.isEmpty()) {
			final Measure measure = reversedStack.pop();
			measure.aggregateIntoMap(aggregates, measuresOrder, currentPath);
		}
		int longestPath = 0;
		for (final List<String> measurePath : measuresOrder) {
			final int pathLength = measurePath.size();
			if (pathLength > longestPath) {
				longestPath = pathLength;
			}
		}
		for (final List<String> measurePath : measuresOrder) {
			final int lastPathPos = measurePath.size() - 1;
			result.add(StringUtils.repeat("\t", lastPathPos) + measurePath.get(lastPathPos)
					+ StringUtils.repeat("\t", longestPath - lastPathPos) + aggregates.get(measurePath));
		}
		return result;
	}

	public void flushStatsToLog(final String timerName) {
		for (final String stat : getStats(timerName)) {
			LOG.info(stat);
		}
	}

	public void flushStatsToLog(final String timerName, final int threshold) {
		if (timers.get(timerName).size() >= threshold) {
			for (final String stat : getStats(timerName)) {
				LOG.info(stat);
			}
		}
	}
}
