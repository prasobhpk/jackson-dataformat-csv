package com.pkp.et.kpi;

/**
 * The kpi type.
 */
public enum KpiType {

	/**
	 * List of all available kpi type.
	 */
	TYPE1(), //
	TYPE2();

	private KpiType() {
	}

}
