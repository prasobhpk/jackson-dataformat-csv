package com.pkp.et.common.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Helper for managing files.
 *
 */
public final class FileHelper {

	private static final Logger LOG = LoggerFactory.getLogger(FileHelper.class);

	/**
	 * Constructor.
	 */
	private FileHelper() {
	}

	/**
	 * @param file
	 *            the zip file to check
	 * @return true if the file is a valid zip file
	 */
	public static boolean validateZipFile(final File file) {
		ZipFile zipfile = null;
		if (file == null) {
			LOG.debug("cannot validate a null file");
			return false;
		}
		try {
			zipfile = new ZipFile(file);
			LOG.debug("file {} is a valid zip file", new Object[] { zipfile });
			return true;
		} catch (final IOException e) {
			LOG.debug("file {} is an invalid zip file", new Object[] { zipfile });
			return false;
		} finally {
			try {
				if (zipfile != null) {
					zipfile.close();
					zipfile = null;
				}
			} catch (final IOException e) {
				LOG.error("error while closing file " + zipfile, e);
			}
		}
	}

	/**
	 * Unzip a file to a directory.
	 * 
	 * @param fileToUnzip
	 *            the file to unzip
	 * @param directory
	 *            the target directory.
	 * @throws ZipException
	 * @throws IOException
	 */
	public static void unzipFile(final File fileToUnzip, final File directory) throws ZipException, IOException {
		final ZipFile zipFile = new ZipFile(fileToUnzip);
		final Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
		while (enumeration.hasMoreElements()) {
			final ZipEntry zipEntry = enumeration.nextElement();
			FileHelper.unzipEntry(zipFile, zipEntry, directory, zipEntry.getName());
		}

		zipFile.close();
	}

	/**
	 * Unzip a zip entry to a file.
	 * 
	 * @param zipfile
	 *            The zip file containing the zip entry to unzip
	 * @param entry
	 *            The zip entry to unzip.
	 * @param outputDir
	 *            The output directory.
	 * @param outputName
	 *            The name of the unziped file.
	 * @return The file unziped.
	 * @throws IOException
	 */
	public static File unzipEntry(final ZipFile zipfile, final ZipEntry entry, final File outputDir,
			final String outputName) throws IOException {

		final File outputFile = new File(outputDir, outputName);

		final BufferedInputStream inputStream = new BufferedInputStream(zipfile.getInputStream(entry));
		final BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(outputFile));

		try {
			IOUtils.copy(inputStream, outputStream);
		} catch (final IOException ioe) {
			LOG.error(ioe.getMessage());
			throw ioe;
		} finally {
			outputStream.close();
			inputStream.close();
		}

		return outputFile;
	}

	/**
	 * Move a file to a specific directory.
	 * 
	 * @param file
	 *            the file to move
	 * @param targetDirectory
	 *            the target directory
	 * @throws IOException
	 *             thrown when any error occurs.
	 */
	public static File moveFileToDirectory(final File file, final File targetDirectory) throws IOException {
		if (file.exists()) {
			final File destFile = new File(targetDirectory.getAbsolutePath() + File.separator + file.getName());
			if (destFile.exists()) {
				FileUtils.deleteQuietly(destFile);
			}
			FileUtils.moveFileToDirectory(file, targetDirectory, true);
			return new File(targetDirectory.getAbsolutePath() + File.separator + file.getName());
		}
		return null;
	}

	/**
	 * Delete a directory and its contains.
	 * 
	 * @param directory
	 *            directory to delete
	 * @throws IOException
	 *             thrown when any error occurs.
	 */
	public static void deleteDirectory(final File directory) throws IOException {
		LOG.info("delete directory {}", directory);
		FileUtils.deleteDirectory(directory);
	}

	/**
	 * Copy a file to a directory.
	 * 
	 * @param file
	 *            the file to copy.
	 * @param targetDirectory
	 *            the target directory.
	 * @throws IOException
	 *             thrown when any error occurs.
	 */
	public static void copyFileToDirectory(final File file, final File targetDirectory) throws IOException {
		FileUtils.copyFileToDirectory(file, targetDirectory, true);
	}

	/**
	 * Create a directory.
	 * 
	 * @param directoryName
	 *            the name of the directory to create.
	 * @throws IOException
	 *             thrown when any error occurs.
	 * @return the created directory
	 */
	public static File createDirectory(final String directoryName) throws IOException {
		final File directory = new File(directoryName);
		FileUtils.forceMkdir(directory);
		return directory;
	}

	/**
	 * Delete a file, no error if an error occur.
	 * 
	 * @param file
	 *            file to delete
	 */
	public static void deleteQuietly(final File file) {
		LOG.info("delete file {}", file);
		FileUtils.deleteQuietly(file);
	}

	public static boolean contentEquals(final File file1, final File file2) throws IOException {
		boolean equals = false;

		if (file1 != null && file2 != null && file1.exists() && file1.isFile() && file2.exists() && file2.isFile()) {
			final String content1 = FileUtils.readFileToString(file1).replaceAll("\r\n", "\n");
			final String content2 = FileUtils.readFileToString(file2).replaceAll("\r\n", "\n");

			equals = content1.equals(content2);
		}

		return equals;
	}

	public static void cleanDirectory(final File directory) throws IOException {
		LOG.info("Cleaning directory {}", directory);
		FileUtils.cleanDirectory(directory);
	}

}
