package com.pkp.et.common.util;

import java.util.Properties;

import org.jasypt.commons.CommonUtils;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.properties.PropertyValueEncryptionUtils;
import org.jasypt.util.text.TextEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.Constants;

/**
 * PropertyPlaceholderConfigurer that decrypt the encoded property values and
 * log all properties
 *
 */
public class EncryptablePropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer {

	private static final Logger LOG = LoggerFactory.getLogger(EncryptablePropertyPlaceholderConfigurer.class);

	private static final String PASSWORD_PROPERTY_NAME_PART = "password";
	protected static final String LOGGED_PASSWORD_PROPERTY_VALUE = "<confidential>";
	private static final String ENC_PROPERTY_NAME_PART = ".ENC";

	private static final Constants CONSTANTS = new Constants(EncryptablePropertyPlaceholderConfigurer.class);

	private int systemPropertiesMode;
	/*
	 * Only one of these instances will be initialized, the other one will be
	 * null.
	 */
	private final StringEncryptor stringEncryptor;
	private final TextEncryptor textEncryptor;

	/**
	 * <p>
	 * Creates an <tt>EncryptablePropertyPlaceholderConfigurer</tt> instance
	 * which will use the passed {@link StringEncryptor} object to decrypt
	 * encrypted values.
	 * </p>
	 *
	 * @param stringEncryptor
	 *            the {@link StringEncryptor} to be used do decrypt values. It
	 *            can not be null.
	 */
	public EncryptablePropertyPlaceholderConfigurer(final StringEncryptor stringEncryptor) {
		super();
		CommonUtils.validateNotNull(stringEncryptor, "Encryptor cannot be null");
		this.stringEncryptor = stringEncryptor;
		textEncryptor = null;
	}

	/**
	 * <p>
	 * Creates an <tt>EncryptablePropertyPlaceholderConfigurer</tt> instance
	 * which will use the passed {@link TextEncryptor} object to decrypt
	 * encrypted values.
	 * </p>
	 *
	 * @param textEncryptor
	 *            the {@link TextEncryptor} to be used do decrypt values. It can
	 *            not be null.
	 */
	public EncryptablePropertyPlaceholderConfigurer(final TextEncryptor textEncryptor) {
		super();
		CommonUtils.validateNotNull(textEncryptor, "Encryptor cannot be null");
		stringEncryptor = null;
		this.textEncryptor = textEncryptor;
	}

	@Override
	public void setSystemPropertiesModeName(final String constantName) throws IllegalArgumentException {
		super.setSystemPropertiesModeName(constantName);
		systemPropertiesMode = CONSTANTS.asNumber(constantName).intValue();
	}

	@Override
	public void setSystemPropertiesMode(final int systemPropertiesMode) {
		super.setSystemPropertiesMode(systemPropertiesMode);
		this.systemPropertiesMode = systemPropertiesMode;
	}

	protected String censoredPassword(final String propertyName, final String propertyValue) {
		if (propertyValue != null && propertyValue.equalsIgnoreCase(LOGGED_PASSWORD_PROPERTY_VALUE)) {
			throw new IllegalArgumentException("please set the correct value for property " + propertyName);
		}
		return isConfidential(propertyName, propertyValue) ? LOGGED_PASSWORD_PROPERTY_VALUE : propertyValue;
	}

	private boolean isConfidential(final String propertyName, final String propertyValue) {
		return propertyName.toLowerCase().contains(PASSWORD_PROPERTY_NAME_PART)
				|| propertyName.contains(ENC_PROPERTY_NAME_PART);
	}

	@Override
	protected void processProperties(final ConfigurableListableBeanFactory beanFactoryToProcess,
			final Properties properties) throws BeansException {
		super.processProperties(beanFactoryToProcess, properties);

		if (LOG.isInfoEnabled()) {
			for (final Object propertyKey : properties.keySet()) {
				final String propertyName = (String) propertyKey;
				final String propertyValue = resolvePlaceholder(propertyName, properties, systemPropertiesMode);
				final String loggedPropertyValue = censoredPassword(propertyName, propertyValue);
				LOG.info("Property {} = {}", new Object[] { propertyName, loggedPropertyValue });
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.beans.factory.config.PropertyResourceConfigurer#
	 * convertPropertyValue(java.lang.String)
	 */
	@Override
	protected String convertPropertyValue(final String originalValue) {
		if (!PropertyValueEncryptionUtils.isEncryptedValue(originalValue)) {
			return originalValue;
		}
		if (stringEncryptor != null) {
			return PropertyValueEncryptionUtils.decrypt(originalValue, stringEncryptor);
		}
		return PropertyValueEncryptionUtils.decrypt(originalValue, textEncryptor);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @since 1.8
	 *
	 * @see
	 * org.springframework.beans.factory.config.PropertyPlaceholderConfigurer#
	 * resolveSystemProperty(java.lang.String)
	 */
	@Override
	protected String resolveSystemProperty(final String key) {
		return convertPropertyValue(super.resolveSystemProperty(key));
	}
}
