package com.pkp.et.kpi;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pkp.et.common.util.DateUtil;
import com.pkp.et.common.util.TimeProvider;


/**
 * Util class used to track kpis in application.
 */
@Service
public class KpiManager {

	private static final Logger LOG = LoggerFactory.getLogger(KpiManager.class);

	private static final String DATETIME_ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	private static final String DATE_ISO_FORMAT = "yyyy-MM-dd";

	private TimeProvider timeProvider;

	private final ThreadLocal<Kpi> kpiContext = new ThreadLocal<Kpi>();
	@Inject
	private ObjectMapper mapper;

	private KpiManager() {
	}

	/**
	 * Create and put in the {@link ThreadLocal} a new {@link Kpi} object.
	 * 
	 * @param type
	 *            the kpi type.
	 * @param timeProvider
	 *            the time provider to use.
	 */
	public void initContext(final KpiType type, final TimeProvider timeProvider) {
		this.timeProvider = timeProvider;
		if (this.kpiContext.get() != null) {
			LOG.error("please reset kpi before creating new one");
		}
		final Kpi kpi = Kpi.create(type);
		kpi.setStartDate(timeProvider.getCurrentDate());
		this.kpiContext.set(kpi);
	}

	/**
	 * Persist the {@link Kpi} object stored in the {@link ThreadLocal}, and reset the context. Ensure that
	 * {@link #initContext(KpiType, TimeProvider)} method is called before calling this method.
	 */
	public void persist() {
		final Kpi kpi = this.kpiContext.get();
		if (kpi == null) {
			LOG.error("please initialize kpi before persist it");
		}
		else {
			kpi.setEndDate(this.timeProvider.getCurrentDate());
			kpi.setDuration(kpi.getEndDate().getTime() - kpi.getStartDate().getTime());
			LOG.info("KPI >>>> " + toKPIString(kpi));
			this.kpiContext.set(null);
		}
	}

	/**
	 * Store, if not null, a new value as a String, in the {@link Kpi}.
	 * 
	 * @param type
	 *            the {@link KpiValueType}
	 * @param value
	 *            the value to store.
	 */
	public void value(final KpiValueType type, final Object value) {
		if (value != null) {
			this.value(type, value.toString());
		}
	}

	/**
	 * Store, if not null, a new value as a long, in the {@link Kpi}.
	 * 
	 * @param type
	 *            the {@link KpiValueType}
	 * @param value
	 *            the value to store.
	 */
	public void value(final KpiValueType type, final Long value) {
		if (this.kpiContext.get() == null) {
			LOG.error("please initialize kpi before adding kpi value");
		}
		else if (value != null) {
			this.kpiContext.get().addKpiValue(type, value);
		}
	}

	/**
	 * Store, if not null, a new value as an integer, in the {@link Kpi}.
	 * 
	 * @param type
	 *            the {@link KpiValueType}
	 * @param value
	 *            the value to store.
	 */
	public void value(final KpiValueType type, final Integer value) {
		if (this.kpiContext.get() == null) {
			LOG.error("please initialize kpi before adding kpi value");
		}
		else if (value != null) {
			this.kpiContext.get().addKpiValue(type, new Long(value));
		}
	}

	/**
	 * Store, if not null, a new value as a local date, in the {@link Kpi}.
	 * 
	 * @param type
	 *            the {@link KpiValueType}
	 * @param value
	 *            the value to store.
	 */
	public void value(final KpiValueType type, final LocalDate value) {
		if (this.kpiContext.get() == null) {
			LOG.error("please initialize kpi before adding kpi value");
		}
		else if (value != null) {
			this.kpiContext.get().addKpiValue(type, value);
		}

	}

	/**
	 * Store, if not null, a new value as a String, in the {@link Kpi}.
	 * 
	 * @param type
	 *            the {@link KpiValueType}
	 * @param value
	 *            the value to store.
	 */
	public void value(final KpiValueType type, final String value) {
		if (this.kpiContext.get() == null) {
			LOG.error("please initialize kpi before adding kpi value");
		}
		else if (value != null) {
			this.kpiContext.get().addKpiValue(type, value);
		}
	}

	public boolean isKpiContextExist() {
		return this.kpiContext.get() != null;
	}

	private String toKPIString(Kpi kpi){
		final Map<String, Object> fields=new HashMap<String,Object>();
		final DateTime startTime = new DateTime(kpi.getStartDate());
		final DateTime endTime = new DateTime(kpi.getEndDate());
		fields.put("@timestamp",new DateTime());
		fields.put("startDate", DateUtil.universalFormatOfTime(DATETIME_ISO_FORMAT, startTime));
		fields.put("endDate", DateUtil.universalFormatOfTime(DATETIME_ISO_FORMAT, endTime));
		fields.put("duration", DateUtil.formatPeriodAsTimeString(new Period(startTime, endTime)));
		// set other fields values
		for (final KpiValue kpiValue : kpi.getKpiValues()) {
			final KpiValueType type = kpiValue.getType();
			Object value = null;
			if (KpiValueType.STRING_TYPES.contains(type)) {
				value = kpiValue.getStringValue();
			}
			else if (KpiValueType.KPI_DATE.equals(type) && (kpiValue.getLocalDateValue() != null)) {
				value = DateUtil.localDateToString(kpiValue.getLocalDateValue(), DATE_ISO_FORMAT);
			}
			fields.put(type.getValue(), value);

		}
		try {
			final String json = this.mapper.writeValueAsString(this);
			return json;
		} catch (final JsonProcessingException e) {
			return null;
		}
	}
}
