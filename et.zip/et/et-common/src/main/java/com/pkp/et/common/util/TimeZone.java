package com.pkp.et.common.util;

/**
 * Time zone enum.
 */
public enum TimeZone {
	/*
	 * Joda Time Canonical ID come from
	 * http://joda-time.sourceforge.net/timezones.html
	 */
	AMERICA_LOS_ANGELES("America/Los Angeles", "America/Los_Angeles", -9), //
	AMERICA_NEW_YORK("America/New York", "America/New_York", -6), //
	EUROPE_LONDON("Europe/London", "Europe/London", -1), //
	EUROPE_BERLIN("Europe/Berlin", "Europe/Berlin", 0), //
	EUROPE_MADRID("Europe/Madrid", "Europe/Madrid", 0), //
	EUROPE_PARIS("Europe/Paris", "Europe/Paris", 0),
	EUROPE_WARSAW("Europe/Warsaw", "Europe/Warsaw", 0), //
	ASIA_HONG_KONG("Asia/Hong Kong", "Asia/Hong_Kong", 6), //
	ASIA_SINGAPORE("Asia/Singapore", "Asia/Singapore", 6), //
	ASIA_TOKYO("Asia/Tokyo", "Asia/Tokyo", 7), //
	AUSTRALIA_SYDNEY("Australia/Sydney", "Australia/Sydney", 8);

	/** The enum label. */
	String label;

	/** The Joda time canonical Id. */
	String canonicalId;

	int shiftFromParisTimeInHours;

	/**
	 * Constructor.
	 * 
	 * @param label
	 *            The label
	 * @param canonicalId
	 *            The Joda time canonical Id
	 */
	private TimeZone(final String label, final String canonicalId, final int shiftFromParisTimeInHours) {
		this.label = label;
		this.canonicalId = canonicalId;
		this.shiftFromParisTimeInHours = shiftFromParisTimeInHours;
	}

	/**
	 * Getter for label.
	 * 
	 * @return the label
	 */
	public String getLabel() {
		return this.label;
	}

	/**
	 * Getter for canonical id.
	 * 
	 * @return The canonicalId
	 */
	public String getCanonicalId() {
		return this.canonicalId;
	}

	public int getShiftFromParisTimeInHours() {
		return this.shiftFromParisTimeInHours;
	}

	public static TimeZone getTimeZoneFromValue(final String value) {
		if (value != null) {
			for (final TimeZone timeZone : TimeZone.values()) {
				if (value.equalsIgnoreCase(timeZone.getLabel())) {
					return timeZone;
				}
			}
		}
		return EUROPE_PARIS;
	}
}
