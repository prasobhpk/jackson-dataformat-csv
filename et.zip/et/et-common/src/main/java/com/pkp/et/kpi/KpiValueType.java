package com.pkp.et.kpi;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.pkp.et.common.util.StringComponent;

/**
 * The kpi value type.
 */
@SuppressWarnings("serial")
public class KpiValueType extends StringComponent implements Serializable {

	/**
	 * List of all available kpi value type.
	 */
	public static final KpiValueType DATA_SOURCE = new KpiValueType("DATA_SOURCE");
	public static final KpiValueType WORK_STATUS = new KpiValueType("WORK_STATUS");
	public static final KpiValueType FAILURE_REASON = new KpiValueType("FAILURE_REASON");
	public static final KpiValueType KPI_DATE = new KpiValueType("KPI_DATE");

	public static final List<KpiValueType> STRING_TYPES = new ImmutableList.Builder<KpiValueType>().add(DATA_SOURCE, WORK_STATUS, FAILURE_REASON).build();

	/**
	 * Default constructor.
	 */
	public KpiValueType() {
	}

	/**
	 * Constructor.
	 * 
	 * @param value
	 */
	public KpiValueType(final String value) {
		super(value);
	}

}
