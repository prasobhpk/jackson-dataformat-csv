package com.pkp.et.kpi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.joda.time.LocalDate;

/**
 * Kpi for application.
 */
public class Kpi {

	private Long id;

	private KpiType type;

	private Date startDate;

	private Date endDate;

	private Long duration;

	private List<KpiValue> kpiValues;

	/**
	 * Create method.
	 * 
	 * @param type
	 *            the kpi type.
	 * @return a new Kpi.
	 */
	public static Kpi create(final KpiType type) {
		final Kpi kpi = new Kpi();
		kpi.init();
		kpi.type = type;
		return kpi;
	}

	private void init() {
		this.kpiValues = new ArrayList<KpiValue>();
	}

	/**
	 * Add a new long {@link KpiValue} to store.
	 * 
	 * @param type
	 *            the kpi value type.
	 * @param longValue
	 *            the new kpi value.
	 */
	public void addKpiValue(final KpiValueType type, final Long longValue) {
		final KpiValue kpiValue = KpiValue.create(type);
		kpiValue.setLongValue(longValue);
		this.kpiValues.add(kpiValue);
	}

	/**
	 * Add a new local date {@link KpiValue} to store.
	 * 
	 * @param type
	 *            the kpi value type.
	 * 
	 * @param localDateValue
	 *            the new kpi value.
	 */
	public void addKpiValue(final KpiValueType type,
			final LocalDate localDateValue) {
		final KpiValue kpiValue = KpiValue.create(type);
		kpiValue.setLocalDateValue(localDateValue);
		this.kpiValues.add(kpiValue);
	}

	/**
	 * Add a new string {@link KpiValue} to store.
	 * 
	 * @param type
	 *            the kpi value type.
	 * 
	 * @param stringValue
	 *            the new kpi value.
	 */
	public void addKpiValue(final KpiValueType type, final String stringValue) {
		final KpiValue kpiValue = KpiValue.create(type);
		kpiValue.setStringValue(stringValue);
		this.kpiValues.add(kpiValue);
	}

	public void setDuration(final long duration) {
		this.duration = duration;
	}

	public void setStartDate(final Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(final Date endDate) {
		this.endDate = endDate;
	}

	public KpiType getType() {
		return this.type;
	}

	public long getDuration() {
		return this.duration;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public List<KpiValue> getKpiValues() {
		return Collections.unmodifiableList(this.kpiValues);
	}

	@Override
	public String toString() {
		return "Kpi [id=" + this.id + ", type=" + this.type + ", startDate="
				+ this.startDate + ", endDate=" + this.endDate + ", duration="
				+ this.duration + ", kpiValues=" + this.kpiValues + "]";
	}

}
