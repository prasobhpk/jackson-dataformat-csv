package com.pkp.et.common.util;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;


/**
 * A Time Provider that returns a given fixed time for demonstration/test
 * purpose.
 */
public class FixedTimeProvider implements TimeProvider {

	private long currentTime;
	private DateTimeZone dateTimeZone;

	@Override
	public long getCurrentTime() {
		return this.currentTime;
	}

	@Override
	public DateTime getCurrentDateTime() {
		return DateUtil.convertDateToDateTimeAtTimeZone(getCurrentDate(), getDateTimeZone());
	}

	public LocalDate getCurrentLocalDate() {
		return DateUtil.convertDateAtParisZoneToLocalDate(getCurrentDate());
	}

	@Override
	public Date getCurrentDate() {
		return new Date(this.currentTime);
	}

	/**
	 * Allow to fixed the time to a given value.
	 * 
	 * @param currentTime
	 *            the current time to set
	 */
	public void setCurrentTime(final long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * Allow to fixed the date to a given value.
	 * 
	 * @param currentDate
	 *            the current date to set
	 */
	public void setCurrentDate(final Date currentDate) {
		this.currentTime = currentDate.getTime();
	}

	/**
	 * Allow to fixed the date to a given value.
	 * 
	 * @param currentDate
	 *            the current date to set
	 */
	public void setCurrentDateTime(final DateTime currentTime) {
		this.currentTime = currentTime.getMillis();
	}

	public DateTimeZone getDateTimeZone() {
		return this.dateTimeZone == null ? DateUtil.PARIS_TIME_ZONE : this.dateTimeZone;
	}

	public void setDateTimeZone(final DateTimeZone dateTimeZone) {
		this.dateTimeZone = dateTimeZone;
	}
}
