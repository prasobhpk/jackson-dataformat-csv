package com.pkp.et.kpi;

import org.joda.time.LocalDate;


/**
 * A value of a kpi.
 */
public class KpiValue{
	private Long id;

	private KpiValueType type;

	private String stringValue;

	private Long longValue;

	private LocalDate localDateValue;

	/**
	 * Create method.
	 * 
	 * @param type
	 *            the kpi value type.
	 * @return a new Kpi value.
	 */
	public static KpiValue create(final KpiValueType type) {
		final KpiValue kpiValue = new KpiValue();
		kpiValue.type = type;
		return kpiValue;
	}

	public String getStringValue() {
		return this.stringValue;
	}

	public void setStringValue(final String stringValue) {
		this.stringValue = stringValue;
	}

	public Long getLongValue() {
		return this.longValue;
	}

	public void setLongValue(final Long longValue) {
		this.longValue = longValue;
	}

	public LocalDate getLocalDateValue() {
		return this.localDateValue;
	}

	public void setLocalDateValue(final LocalDate localDateValue) {
		this.localDateValue = localDateValue;
	}

	public KpiValueType getType() {
		return this.type;
	}


	@Override
	public String toString() {
		return "KpiValue [id=" + this.id + ", type=" + this.type + ", stringValue=" + this.stringValue + ", longValue="
				+ this.longValue + ", localDateValue=" + this.localDateValue + "]";
	}

}
