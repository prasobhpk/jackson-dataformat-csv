package pkp.wm.domain;

public enum UserGroupEnum {
    CONTACT, SALES, SUPPORT, DEVELOPER, ADMIN;
}
