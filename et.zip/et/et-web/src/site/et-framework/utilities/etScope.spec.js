describe('** Scope service test **', function() {
  var service;
  var $rootScope;

  beforeEach(module('ezweb-core'));

  beforeEach(inject(function(_ezScope_, _$rootScope_) {
    service = _ezScope_;
    $rootScope = _$rootScope_;
  }));

  it('Should init the service', function() {
    expect(service).toBeDefined();
  });

  it('Should store an object in a simple namespace', function() {
    service.ensure('test', {simpleProperty: 'go'});
    expect(service.test.simpleProperty).toEqual('go');
  });

  it('Should store an object in a complex namespace', function() {
    service.ensure('test.example.properties', {simpleProperty: 'go', otherProperty: 5});
    expect(service.test.example.properties.simpleProperty).toEqual('go');
    expect(service.test.example.properties.otherProperty).toEqual(5);
  });

  it('Should not allow an empty namespace when calling the ensure mezhod', function() {
    service.ensure('', {simpleProperty: 'go'});
    expect(service.simpleProperty).toBeUndefined();
  });
});
