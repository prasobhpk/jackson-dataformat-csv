/**
 * @ngdoc type
 * @name etNamespace
 * @module etweb-core
 *
 * @description
 * Allows configuration of an object without worrying if it is defined or not.
 *
 * Do not manipulate the root namespace directly.
 * Use the {@link etAppScope Application Scope Service}.
 */
function etNamespace() {
}

/**
 * @ngdoc method
 * @name etNamespace#ensure
 * @memberof etNamespace
 *
 * @param {string|Array} namespace The namespace to ensure. This can be an array of string or a string with
 * dot-notation.
 *
 * @param {object} options The values we want to test the existence of, in the context of the namespace
 * @returns {etNamespace} The ensured namespace.
 *
 * @description
 * Makes sure some values are set in a namespace. If the namespace doesn't exist, it will be created.
 *
 * For example (you need to inject the {@link etAppScope Application Scope Service}):
 * ```js
 * etAppScope.ensure('configuration', {
 *     paths: 'xyz'
 * });
 * ```
 * If you put this somewhere else in the application configuration:
 * ```js
 * etAppScope.ensure('configuration.party', {
 *     et: true
 * });
 * ```
 * Then your app scope will look like this, regardless of what order the two instructions above were executed:
 * ```js
 * configuration: {
 *     paths: 'xys',
 *     party: {
 *         et: true
 *     }
 * }
 * ```
 * Both `$rootScope.app.configuration` and `$rootScope.app.configuration.party` have the `ensure()` method.
 */
etNamespace.prototype.ensure = function (namespace, options) {
  if (angular.isArray(namespace)) {
    if (namespace.length === 0) {
      angular.extend(this, options);
      return this;
    }
    else {
      var toEnsure = namespace.shift();

      if (!this[toEnsure]) {
        this[toEnsure] = new etNamespace();
      }
      return this[toEnsure].ensure(namespace, options);
    }
  }
  else {
    return this.ensure(namespace.split('.'), options);
  }
};

angular.module('etweb-core')
  .constant('etNamespace', etNamespace)
  .factory('etScope', ['$rootScope', function ($rootScope) {
    /**
     * @ngdoc service
     * @name etScope
     * @module etweb-core
     *
     * @description
     * This is the service that registers everything the etWeb framework makes available in the root scope.
     *
     * <div class="alert alert-danger">
     * This service should not be used in the application. It is intended for internal use only. To make
     * application level configuration available, use the {@link etAppScope} instead.
     * </div>
     */
    $rootScope.etweb = new etNamespace();
    return $rootScope.etweb;
  }])
  .factory('etAppScope', ['$rootScope', function ($rootScope) {
    /**
     * @ngdoc service
     * @name etAppScope
     * @module etweb-core
     *
     * @description
     * Registers a namespace under $rootScope.app. This allows the application to keep configuration
     * available to all views, controllers and directives.
     *
     * The service is a {@link etNamespace}, so you can `ensure()` your configuration is there without taking
     * care of the order in which the different config blocks of your app are run.
     *
     * To access the values set in the appScopeService, you can bind on `app.path.to.my.value`,
     * or $watch `$scope.app.path.to.my.value`.
     */
    $rootScope.app = new etNamespace();
    return $rootScope.app;
  }])
;
