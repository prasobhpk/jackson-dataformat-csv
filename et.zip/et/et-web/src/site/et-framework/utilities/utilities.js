angular.module('etweb-core')
  .directive('etFocus', function($timeout) {
    /**
     * @ngdoc directive
     * @name etFocus
     * @module etweb-core
     *
     * @restrict A
     * @description
     * The etFocus directive puts the focus on the current input or on the first input found in an element
     * when the associated expression turns `true` or immediately if the expression is not found.
     *
     * @element ANY
     * @param {expression} [etFocus="true"] When the expression turns `true` the focus is given to the input
     *      on which `etFocus` is set. If the expression is not defined the focus is given immediately.
     *      If `etFocus` is not set on an input type element (e.g. `input`, `textarea` or `select`) then the
     *      first input type element inside the element on which `etFocus` is set will get the focus.
     */
    return {
      scope: {trigger: '&etFocus'},
      link: function($scope, $element, $attrs) {
        var focus = function() {
          $timeout(function() {
            var $input = $element.is('input,select,textarea') ?
              $element :
              $element.find('input,select,textarea');
            if ($input.length > 0) {
              $input[0].focus();
            }
          });
        };
        if ($attrs.etFocus.length > 0) {
          $scope.$watch('trigger()', function(trigger) {
            if (trigger === true) {
              focus();
            }
          });
        }
        else {
          focus();
        }
      }
    };
  })
  .directive('etLoadingIndicator', function() {
    /**
     * @ngdoc directive
     * @name etLoadingIndicator
     * @module etweb-core
     *
     * @restrict AE
     * @description
     * Show a loading indicator to make the user wait.
     *
     * @element div|span
     * @param {string} message The message to show to the user next to the loading indicator.
     *      This should describe what we are waiting for, e.g. `Loading products...`
     * @param {expression} showWhen The indicator will be shown when this expression is `true`.
     *      When you are waiting on a `ngResource`, you will typically use `show-when="!myResource.$resolved"`.
     *
     * @example
     * <example module="example-etLoadingIndicator">
     *   <file name="index.html">
     *     <div ng-controller="ExampleetLoadingIndicator as control">
     *       <form role="form">
     *         <et-form-checkbox et-label="Show indicator" ng-model="control.shown">
     *         </et-form-checkbox>
     *         <et-form-text et-label="Message"
     *                 ng-model="control.message"></et-form-text>
     *       </form>
     *       <et-loading-indicator message="{{control.message}}"
     *                   show-when="control.shown"></et-loading-indicator>
     *     </div>
     *   </file>
     *   <file name="controller.js">
     *     angular.module('example-etLoadingIndicator', ['etweb-core'])
     *     .controller('ExampleetLoadingIndicator', [
     *       function() {
     *         this.shown = true;
     *         this.message = 'Loading data...';
     *       }
     *     ])
     *     ;
     *   </file>
     * </example>
     */
    return {
      restrict: 'AE',
      scope: {
        message: '@',
        showWhen: '&'
      },
      templateUrl: 'loadingIndicator.html'
    };
  })
;
