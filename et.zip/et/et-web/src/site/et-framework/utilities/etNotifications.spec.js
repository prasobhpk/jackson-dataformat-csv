describe('** Notification provider test **', function() {
  var service;

  beforeEach(module('etweb-core'));

  beforeEach(inject(function(_etNotifications_) {
    service = _etNotifications_;
  }));

  it('Should init the service', function() {
    expect(service).toBeDefined();
  });
});
