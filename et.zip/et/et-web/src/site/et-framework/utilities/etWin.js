angular.module('etweb-core')
  .factory('etWin', ['$window', '$rootScope', '$timeout', 'etScope', function ($window, $rootScope, $timeout, etScope) {
    /**
     * @ngdoc service
     * @name etWin
     * @module etweb-core
     * @description
     * Makes the browser window size and size changes available.
     *
     * All the properties and methods of this service are published on the root scope in `etweb.win`, so
     * they can be bound and watched.
     *
     * It is recommended to use the `watch()` method of this service instead of `Scope.$watch()` to watch
     * the size of the window. This service makes sure the element sizes are available (window has refreshed)
     * and makes optimizations to prevent the lengthy size calculations we do on window size change from
     * hanging the application.
     *
     * @property {object} size This is available in the root scope as `etweb.win.size`.
     * This object has the following properties:
     * ```js
     * {
     *   width: number: The window width (in px)
     *   height: number: The window height (in px)
     *   change: number: Internal pointer to the number of times the window size has changed
     * }
     * ```
     */
    var $$window = angular.element($window);
    etScope.ensure('win', {
      size: {
        width: $$window.outerWidth(true),
        height: $$window.outerHeight(true),
        change: 0,
        scrollTop: $$window.scrollTop(),
        scrollLeft: $$window.scrollLeft(),
        scrollChange: 0
      },
      /**
       * @ngdoc method
       * @name etWin#watch
       * @memberof etWin
       *
       * @param {function()} callback The function to call on window resize. It can take exactly one
       * parameter, which is the `size` object of this service.
       * @returns {function()} A deregistration function for this listener (same as Scope.$watch)
       *
       * @description
       * Watches window resize
       */
      watch: function (callback) {
        return $rootScope.$watch('etweb.win.size.change', function () {
          callback(etScope.win.size);
        });
      },
      /**
       * @ngdoc method
       * @name etWin#watchScroll
       * @memberof etWin
       *
       * @param {function()} callback The function to call on window scroll. It can take exactly one
       * parameter, which is the `size` object of this service.
       * @returns {function()} A deregistration function for this listener (same as Scope.$watch)
       *
       * @description
       * Watches window resize
       */
      watchScroll: function (callback) {
        return $rootScope.$watch('etweb.win.size.scrollChange', function () {
          callback(etScope.win.size);
        });
      },
      /**
       * @ngdoc method
       * @name etWin#scollTo
       * @memberof etWin
       *
       * @param {function()} callback The function to call on window scroll. It can take exactly one
       * parameter, which is the `size` object of this service.
       * @returns {function()} A deregistration function for this listener (same as Scope.$watch)
       *
       * @description
       * Watches window resize
       */
      scrollTo: function (scrollLeft, scrollTop) {
        if (scrollTop) {
          $$window.scrollTop(scrollTop);
        }
        if (scrollLeft) {
          $$window.scrollLeft(scrollLeft);
        }
      }
    });

    var resizeTimeout = null;
    $$window.on('resize', function () {
      if (resizeTimeout !== null) {
        $timeout.cancel(resizeTimeout);
      }
      resizeTimeout = $timeout(function () {
        // Timeout allows time for the browser to redraw, and makes sure window
        // size change animations don't trigger cpu intensive calculations and
        // $digest cycles for nothing
        etScope.win.size.width = $$window.outerWidth(true);
        etScope.win.size.height = $$window.outerHeight(true);
        etScope.win.size.change++;
        resizeTimeout = null;
      }, 100);
    });

    var scrollTimeout = null;
    $$window.on('scroll', function () {
      if (scrollTimeout !== null) {
        $timeout.cancel(scrollTimeout);
      }
      scrollTimeout = $timeout(function () {
        // Timeout makes sure window scroll change animations don't trigger
        // cpu intensive calculations and $digest cycles for nothing
        etScope.win.size.scrollTop = $$window.scrollTop();
        etScope.win.size.scrollLeft = $$window.scrollLeft();
        etScope.win.size.scrollChange++;
        scrollTimeout = null;
      }, 10);
    });

    return etScope.win;
  }])
  .factory('etCursor', ['$document', '$rootScope', 'etScope', function ($document, $rootScope, etScope) {
    /**
     * @ngdoc service
     * @name etCursor
     * @module etweb-core
     * @description
     * Makes the mouse position available in the scope.
     *
     * You can read these values directly from the scope at `etweb.cursor.*`,
     * or from this service (See the properties list).
     *
     * It is important to note that although the mouse position is updated constantly,
     * for performance reasons this service *does not launch a digest cycle* when that happens.
     *
     * However, it does launch a digest cycle (and executes watchers) when a mouse button is
     * pressed or released.
     *
     * It is your responsibility to update the cursor as needed
     * (by setting an interval and responsibly stopping it when not needed, for example).
     *
     * @property {Number} x The horizontal position of the cursor, starting from the left side of the window.
     *
     * Can be bound with `etweb.cursor.x`, but does not update the scope on change.
     *
     * @property {Number} y The vertical position of the cursor, starting from the top of the window.
     *
     * Can be bound with `etweb.cursor.y`, but does not update the scope on change.
     *
     * @property {boolean} pressed This will be `true` if a button is pressed on the mouse.
     *
     * Can be bound with `etweb.cursor.pressed`.
     */

    etScope.ensure('cursor', {
      x: 0,
      y: 0,
      pressed: false
    });

    $document.on('mousemove', function (event) {
      event = event || window.event;
      etScope.cursor.x = event.clientX;
      etScope.cursor.y = event.clientY;
    });

    $document.on('mousedown', function () {
      $rootScope.$evalAsync(function () {
        etScope.cursor.pressed = true;
      });
    });

    $document.on('mouseup', function () {
      $rootScope.$evalAsync(function () {
        etScope.cursor.pressed = false;
      });
    });

    // This way of detecting cursor leaving the window is strange, but works cross-browser.
    // Based on http://bradsknutson.com/blog/javascript-detect-mouse-leaving-browser-window/
    // Fixed to prevent triggering when the document is shorter than the window
    function addEvent(obj, evt, fn) {
      if (obj.addEventListener) {
        obj.addEventListener(evt, fn, false);
      }
      else if (obj.attachEvent) {
        obj.attachEvent('on' + evt, fn);
      }
    }

    addEvent($document[0], 'mouseout', function (e) {
      e = e ? e : window.event;
      var from = e.relatedTarget || e.toElement;
      if ((!from || from.nodeName == 'HTML') &&
        (e.clientX <= 0 || e.clientX + 5 >= etScope.win.size.width ||
        e.clientY <= 0 || e.clientY + 5 >= etScope.win.size.height)
      ) {
        $rootScope.$evalAsync(function () {
          etScope.cursor.pressed = false;
        });
      }
    });

    return etScope.cursor;
  }])
  .provider('etLocalStorage', function () {
    /**
     * @ngdoc provider
     * @name etLocalStorageProvider
     * @module etweb-core
     * @description
     *
     * Makes the local storage available by injection.
     *
     * This provider gives access to `window.localStorage`.
     * It is there to allow decoupling in unit testing.
     * Using this provider is the preferred way of accessing the browser's local storage.
     */

    /**
     * @ngdoc property
     * @name etLocalStorageProvider#localStorage
     * @memberof etLocalStorageProvider
     * @description
     *
     * The browser's localStorage object
     *
     * @type {object}
     */
    this.localStorage = window.localStorage;

    this.$get = ['$window', function ($window) {
      /**
       * @ngdoc service
       * @name etLocalStorage
       * @module etweb-core
       * @description
       *
       * Makes the local storage available by injection.
       *
       * This service is actually an alias of `window.localStorage`.
       * It is there to allow decoupling in unit testing.
       * Using this service is the preferred way of accessing the browser's local storage.
       */
      return $window.localStorage;
    }];
  })
;
