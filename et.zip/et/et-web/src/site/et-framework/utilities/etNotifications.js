angular.module('etweb-core')
  .factory('etNotifications',['$rootScope', 'etScope',function($rootScope, etScope) {
    /**
     * @ngdoc service
     * @name etNotifications
     * @module etweb-core
     *
     * @description
     * The Notifications service allows an easy management of application notifications.
     * This includes creating notifications with a number of properties, managing their read status and
     * removing them.
     *
     * The notifications service and methods are published in the scope, in `etweb.notifications`.
     *
     * Actually displaying the notifications is left to the application.
     *
     * ## Notification
     * ```js
     * {
     *    id: null,
     *    title: '',
     *    text: '',
     *    importance: 'info', // 'success', 'warning', 'danger'
     *    action: null, // String: url to go to. Function: function to call
     *    read: false, // Set to true to not be count as unread
     *    $read: function() {
     *        ...
     *    },
     *    $remove: function() {
     *        ...
     *    }
     * }
     * ```
     *
     * ### id
     * The ID of the notification is automatically given by the Notification service, and must not be
     * overridden.
     * It is used by several methods of the Notifications service API to act on a specific notification.
     *
     * ### title
     * This is a short title to the notification. It should be clear and concise.
     *
     * ### text
     * This is the text of the notification, that will be displayed fully. It can include angular elements.
     *
     * ### importance
     * This should be set to one of the importance classes from Bootstrap
     * (`info`, `danger`, `warning`, `success`).
     *
     * The Notification service doesn't do anything special with this, but the class names
     * `alert alert-{{notification.importance}}` will be added to the div to display the notification in
     * your app.
     *
     * ### action
     * Specify here what happens when the user 'acts' on the notification
     * (e.g. click, touch, or anything else that your application wants it to do).
     * What exactly happens here is left to the app's specific implementation, but we recommend using
     * the convention:
     * - string: go to url
     * - function: execute the function with no parameters
     *
     * ### read
     * This is `false` by default, but you can set it to `true` and the notification will not be count as an
     * unread notification.
     * This is useful if you don't want to bother your user with a notification change, but still keep it in
     * the notifications list.
     *
     * ### $read()
     * This function is added by the notifications service. You can't override it. Calling it on a
     * notification will mark the notification as read (and decrease the unread count).
     *
     * ### $remove()
     * This function is added by the notifications service. You can't override it. Calling it on a
     * notification will remove the notification from the notifications list.
     */

    /**
     * @ngdoc event
     * @name etNotifications#etNotificationAdded
     * @memberof etNotifications
     * @eventType broadcast on root scope
     *
     * @description
     * Broadcasted when a notification is added.
     *
     * @param {object} notification The added notification with its ID and the `$read()` and
     *     `$remove()` methods
     * @param {number} nbUnread Number of unread notifications after the notification is added
     */

    /**
     * @ngdoc event
     * @name etNotifications#etNotificationRemoved
     * @memberof etNotifications
     * @eventType broadcast on root scope
     *
     * @description
     * Broadcasted when a notification is removed.
     *
     * @param {object} notification The notification that was just removed
     * @param {number} nbUnread Number of unread notifications after the notification is removed
     */

    /**
     * @ngdoc event
     * @name etNotifications#etNotificationRead
     * @memberof etNotifications
     * @eventType broadcast on root scope
     *
     * @description
     * Broadcasted when a notification is read.
     *
     * @param {object} notification The notification that was just read
     * @param {number} nbUnread Number of unread notifications after the notification is read
     */

    var notifications = [];
    var nbUnread = 0;
    var ids = 0;
    var stubNotification = {
      id: null,
      title: '',
      text: '',
      importance: 'info', // 'success', 'warning', 'danger'
      action: null, // String: url to go to. Function: function to call
      read: false, // Set to true to not be count as unread
      $read: function() {
        etScope.notifications.markRead(this.id);
      },
      $remove: function() {
        etScope.notifications.remove(this.id);
      }
    };

    var copy = null;
    $rootScope.$on('etweb.logout', function() {
      notifications = [];
      nbUnread = 0;
      copy = null;
    });

    etScope.ensure('notifications', {
      add: function(notification) {
        /**
         * @ngdoc method
         * @name etNotifications#add
         * @memberof etNotifications
         *
         * @description
         * Adds a notification.
         *
         * The notification should have the form described above. The only required fields are `title`
         * and `text`.
         *
         * @param {object} notification The notification to add.
         * @returns {object} The added notification, with its ID and `$read()` and `$remove()` methods
         */
        copy = null;
        delete notification.id;

        var actualNotification = $.extend({}, stubNotification, notification, {id: ++ids});

        if (actualNotification.read === false) {
          nbUnread++;
        }
        notifications.unshift(actualNotification);

        $rootScope.$broadcast('etNotificationAdded', actualNotification, nbUnread);

        return actualNotification;
      },
      remove: function(notificationId) {
        /**
         * @ngdoc method
         * @name etNotifications#remove
         * @memberof etNotifications
         *
         * @description
         * Removes a notification.
         *
         * @param {string} notificationId The ID of the notification to remove.
         */
        copy = null;

        var indexToRemove = -1;
        angular.forEach(notifications, function(notification, index) {
          if (notification.id === notificationId) {
            indexToRemove = index;
          }
        });

        if (indexToRemove >= 0) {
          if (notifications[indexToRemove].read === false) {
            nbUnread--;
          }
          var removed = notifications[indexToRemove];
          notifications.splice(indexToRemove, 1);
          $rootScope.$broadcast('etNotificationRemoved', removed, nbUnread);
        }
      },
      markRead: function(notificationId) {
        /**
         * @ngdoc method
         * @name etNotifications#markRead
         * @memberof etNotifications
         *
         * @description
         * Marks a notification as read.
         *
         * You shouldn't try to change the notification directly. It will not work, and if it (by chance)
         * does, it will not update the unread count. Using this method ensures that everybody has
         * an up-to-date read status.
         *
         * @param {string} notificationId The ID of the notification that has been read.
         */

        copy = null;

        angular.forEach(notifications, function(notification) {
          if (notification.id === notificationId && notification.read === false) {
            notification.read = true;
            nbUnread--;

            $rootScope.$broadcast('etNotificationRead', notification, nbUnread);
          }
        });
      },
      markAllRead: function() {
        /**
         * @ngdoc method
         * @name etNotifications#markAllRead
         * @memberof etNotifications
         *
         * @description
         * Marks all notification as read.
         *
         * You shouldn't try to change the notifications directly. It will not work, and if it (by chance)
         * does, it will not update the unread count. Using this method ensures that everybody has
         * an up-to-date read status.
         */

        angular.forEach(notifications, function(notification) {
          notification.read = true;
          nbUnread--;
          $rootScope.$broadcast('etNotificationRead', notification, nbUnread);
        });

        copy = null;
      },
      unread: function() {
        /**
         * @ngdoc method
         * @name etNotifications#unread
         * @memberof etNotifications
         *
         * @description
         * Find out how many unread notifications are left.
         *
         * This method is intended for binding: it is available on the root scope at
         * `etweb.notifications.unread()`.
         *
         * @return {number} The number of unread notifications.
         */

        if (nbUnread > 0) {
          return nbUnread;
        }
      },
      all: function() {
        /**
         * @ngdoc method
         * @name etNotifications#all
         * @memberof etNotifications
         *
         * @description
         * Fetches all notifications.
         *
         * This method is intended for binding: it is available on the root scope at
         * `etweb.notifications.all()`.
         *
         * @return {Array} All notifications.
         */

        if (copy === null) {
          copy = angular.copy(notifications);
        }
        return copy;
      }
    });

    return etScope.notifications;
  }])
;
