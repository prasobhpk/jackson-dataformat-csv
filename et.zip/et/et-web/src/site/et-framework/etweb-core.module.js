/**
 * @ngdoc module
 * @name etweb-core
 * @description
 * This module comprises basic utility directives, filters and services that are useful for application development and support the foundation
 * of most etWeb functionality.
 */
angular.module('etweb-core', []);
