angular.module('etweb-core')
    .provider('etPostAuthenticationBackend', function () {
        var defaultConfig = {
            usernameParameter: 'username',
            passwordParameter: 'password',
            rememberMeParameter: 'rememberme',
            supportsRememberMe: true,
            loginUri: 'login',
            logoutUri: 'logout',
            currentUserUri: 'rest/users/current',
            resetPasswordPath: '/forgotPassword'
        };
        var config = defaultConfig;

        this.configure = function (options) {
            config = angular.extend({}, defaultConfig, options);
        };

        // noinspection JSValidateTypes
        this.$get = function ($http, $q) {
            return {
                login: function (username, password, rememberme) {
                    var data = {};
                    data[config.usernameParameter] = username;
                    data[config.passwordParameter] = password;

                    if (config.supportsRememberMe === true) {
                        data[config.rememberMeParameter] = rememberme ? rememberme : false;
                    }

                    var deferred = $q.defer();
                    $.post(config.loginUri, data)
                        .success(function (result) {
                            if (result.username && result.username !== '') {
                                deferred.resolve(result);
                            }
                            else {
                                deferred.reject('Wrong username or password.');
                            }
                        })
                        .error(function () {
                            return deferred.reject('Server error. Please try again. ' +
                                'If the problem persists, contact your administrator.');
                        });
                    return deferred.promise;
                },
                logout: function () {
                    return $http.get(config.logoutUri);
                },
                current: function () {
                    return $http.get(config.currentUserUri)
                        .then(function (result) {
                            return result.data;
                        });
                },
                resetPasswordPath: function () {
                    return config.resetPasswordPath;
                },
                supportsRememberMe: function () {
                    return config.supportsRememberMe;
                }
            };
        };
    })
    .factory('etNoAuthenticationBackend', function ($q) {
        var _fail = function () {
            return $q.reject('No backend chosen. ' +
                'Use etUsers.configure() in a ' +
                'angular.module.run() block.');
        };
        return {
            login: _fail,
            logout: _fail,
            current: _fail,
            reset: _fail,
            supportsRememberMe: function () {
                return false;
            }
        };
    })
;
