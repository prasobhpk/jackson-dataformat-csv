describe('**Testing logout**', function () {
    'use strict';

    var service;
    var $httpBackend;

    beforeEach(module('etweb-core'));

    beforeEach(inject(function (_etPostAuthenticationBackend_, _$httpBackend_) {
        service = _etPostAuthenticationBackend_;
        $httpBackend = _$httpBackend_;
    }));

    it('Should define the service', function () {
        expect(service).toBeDefined();
    });

    it('Should call the default $http URL', function () {
        $httpBackend.expectGET('logout').respond();
        service.logout();
        $httpBackend.flush();
    });
});
