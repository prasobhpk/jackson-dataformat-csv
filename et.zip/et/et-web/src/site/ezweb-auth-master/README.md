# ezweb-auth

ezweb-auth contains a set of directives which handle user login and authentication.


## Installation

```sh
npm install --save-dev ezweb-auth
```

If you do not use `ezweb.start()` (see https://sgithub.fr.world.socgen/CTT-Ezweb/ezweb), you
need to add the `ezweb-auth` AngularJS module as a dependency to your app.


## Configuration

ezweb-auth is based on EZBuild build system. Its configuration file, `ezbuild.conf.js` is located at the root of the
repository.

It is automatically executed when the EZWeb application is run.


## API documentation

The API documentation is here: https://ezweb.fr.world.socgen/#/api/ezweb-auth


## Code coverage

The code coverage is here: https://ezweb.fr.world.socgen/#/testing/coverage/ezweb-auth


## How to contribute

### Install library in development mode

If you want to contribute to ezweb-auth, you can install it in your application, in development mode.

This way you can update it and test the new behavior directly in your application.

1. Remove the `ezweb-auth` folder from `yourApp/node_modules`
2. Fork the SGithub [ezweb-auth](https://sgithub.fr.world.socgen/CTT-Ezweb/ezweb-auth) repository
3. Clone **YOUR** ezweb-auth repository into `yourApp/node_modules`
4. Run `npm install` from `yourApp/node_modules/ezweb-auth`
5. Run `gulp serve` from `yourApp/node_modules/ezweb-auth`
6. Run `gulp serve` from `yourApp`

Now when you update `yourApp/node_modules/ezweb-auth` files, and rerun `gulp serve` from
`yourApp/node_modules/ezweb-auth` to build it, your changes should be available in your application.

If not, try stopping and running `gulp serve` again from `yourApp`.

### Contribute

When your new feature is **working**, **documented**, and **successfully tested**, you can ask the EZWeb team to
integrate it into the official [ezweb-auth](https://sgithub.fr.world.socgen/CTT-Ezweb/ezweb-auth) repository.

1. Commit and push your changes in your forked repository
2. Create a Pull Request on the official ezweb-auth repository, and add in the comment field an explanation of your
work.

The EZWeb team will be notified, will check your request, and may decide to integrate the new feature into the
repository.
