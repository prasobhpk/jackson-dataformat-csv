function selectScopeWithetweb(fromScope) {
  if (fromScope.etweb) {
    return fromScope;
  }
  else {
    return selectScopeWithetweb(fromScope.$parent);
  }
}

function watchAction(condition, $scope, $element, $transclude) {
  // This code is copy-pasted from the ngIf directive with small adaptations
  var block;
  return function (value) {
    if (condition(value) === true) {
      if (!block) {
        $transclude($scope, function (clone) {
          block = {
            clone: clone
          };
          $element.after(clone);
        });
      }
    }
    else {
      if (block) {
        block.clone.remove();
        block = null;
      }
    }
  };
}

angular.module('etweb-auth')
  .provider('etUsers', function () {
    var disconnectedUser = {
      username: null,
      roles: [],
      connected: false
    };
    var checkingConnection = false;
    var connectionChecked = false;

    // This function is dependency injected using $inject (see below the function)
    var etUsers = function (backend, $q, scopeService, $rootScope) {
      if (!angular.isFunction(backend.login)) {
        throw "Backend doesn't define the login() function. See docs.";
      }
      if (!angular.isFunction(backend.logout)) {
        throw "Backend doesn't define the logout() function. See docs.";
      }
      if (!angular.isFunction(backend.current)) {
        throw "Backend doesn't define the current() function. See docs.";
      }
      scopeService.ensure('backends', {
        users: {hasRememberMe: backend.supportsRememberMe()}
      });

      scopeService.ensure('user', angular.extend({}, disconnectedUser, {

        /**
         * Logs the currently logged in user out of the system.
         *
         * If the user is not logged in, does nothing.
         *
         * @returns {promise} A promise that indicates success or error of the logout.
         * On success, the `etweb.logout` event is broadcasted on the root scope
         */
        logout: function () {
          if (scopeService.user.connected === true) {
            return backend.logout()
              .then(function () {
                $rootScope.$broadcast('etweb.logout', scopeService.user);
                angular.extend(scopeService.user, disconnectedUser);
                return scopeService.user;
              });
          }
          else {
            return $q.when(this);
          }
        },
        /**
         * Only use this function if you know the user has been logged out of the system.
         *
         * This will consider the user logged out, without sending any events or requests
         * to the server, in effect resetting the logged-in state of the user.
         *
         * Good practice is to only use this method in the user service configuration,
         * for example to respond to a push event telling the user it has been logged out.
         */
        considerLoggedOut: function () {
          angular.extend(scopeService.user, disconnectedUser);
        },
        /**
         * Logs in the user into the system.
         *
         * @param username {string} The user login name
         * @param password {string} The user's password
         * @param rememberme {boolean} Should we remember the user on the server ?
         * @return {promise} A promise that indicates success or error of the login.
         * On success, the connected user's information is passed as the result and the
         * 'etweb.login' event is broadcasted on the root scope.
         */
        login: function (username, password, rememberme) {
          if (scopeService.user.connected === true) {
            return $q.reject('User is already logged in.');
          }

          return backend.login(username, password, rememberme)
            .then(function (result) {
              angular.extend(scopeService.user, result);
              scopeService.user.connected = true;
              connectionChecked = true;
              $rootScope.$broadcast('etweb.login', scopeService.user);
              return scopeService.user;
            });
        },
        /**
         * Resets the password of the user.
         *
         * @param username The name of the user whose password will be reset
         * @returns {*}
         */
        resetPasswordPath: function () {
          return backend.resetPasswordPath();
        },
        /**
         * Get the currently connected user.
         *
         * @param callback The callback called when the user's connection status is known.
         * First and only argument to the callback is the user.
         * @returns {object} the user. Until the user is known, this is an anonymous user.
         * It will change to a known user when the identity of the user is established.
         * This value can be used as-is in scope bindings.
         */
        get: function (callback) {
          callback = callback ? callback : angular.noop;

          if (connectionChecked === true) {
            callback(scopeService.user);
            return scopeService.user;
          }

          if (checkingConnection !== false) {
            checkingConnection = checkingConnection.then(function () {
              callback(scopeService.user);
              return scopeService.user;
            });
            return scopeService.user;
          }

          checkingConnection = backend.current()
            .then(function (result) {
              angular.extend(scopeService.user, result);
              scopeService.user.connected = true;
              $rootScope.$broadcast('etweb.connected', scopeService.user);
              callback(scopeService.user);
              checkingConnection = false;
              connectionChecked = true;
              return scopeService.user;
            }, function () {
              checkingConnection = false;
            });

          return scopeService.user;
        },
        consider: function (user) {
          angular.extend(scopeService.user, user);
        }
      }));
      scopeService.user.get();

      return scopeService.user;
    };

    etUsers.$inject = [
      'etNoAuthenticationBackend',
      '$q',
      'etScope',
      '$rootScope'
    ];

    this.configure = function (userServiceBackend) {
      if (arguments.length === 0 || userServiceBackend === null) {
        throw 'No backend defined';
      }

      etUsers.$inject[0] = userServiceBackend;
    };

    this.$get = etUsers;

  })
  .directive('etUserRequireLoggedIn', [
    'etUsers', // Keep it there, it loads the service on first use
    function () {
      return {
        restrict: 'A',
        transclude: 'element',
        priority: 10000,
        terminal: true,
        scope: false,
        link: function ($scope, $element, $attrs, ctrl, $transclude) {
          selectScopeWithetweb($scope).$watch(':auth: etweb.user.connected', watchAction(function (connected) {
            return connected;
          }, $scope, $element, $transclude));
        }
      };
    }
  ])
  .directive('etUserRequireLoggedOut', [
    'etUsers', // Keep it there, it loads the service on first use
    function () {
      return {
        restrict: 'A',
        transclude: 'element',
        priority: 10000,
        terminal: true,
        scope: false,
        link: function ($scope, $element, $attrs, ctrl, $transclude) {
          selectScopeWithetweb($scope).$watch(':auth: etweb.user.connected', watchAction(function (connected) {
            return !connected;
          }, $scope, $element, $transclude));
        }
      };
    }
  ])
  .directive('etUserHasRole', [
    'etUsers', // Keep it there, it loads the service on first use
    function () {
      return {
        restrict: 'A',
        transclude: 'element',
        priority: 10000,
        terminal: true,
        scope: false,
        link: function ($scope, $element, $attrs, ctrl, $transclude) {
          // noinspection JSUnresolvedVariable
          var role = $attrs.etUserHasRole;
          selectScopeWithetweb($scope).$watch(':auth: etweb.user.roles', watchAction(function (roles) {
            return $.inArray(role, roles) >= 0;
          }, $scope, $element, $transclude));
        }
      };
    }
  ])
;
