/**
 * @ngdoc module
 * @name ezweb-auth
 * @description
 * Manage user authentication to a server.
 *
 * Provides widgets to help in the authentication-related tasks.
 */
angular.module('ezweb-auth', [
  'ezweb-auth-templates',
  'ezweb-once',
  'ezweb-core',
  'ezweb-form',
  'ezweb-i18n'
]);
