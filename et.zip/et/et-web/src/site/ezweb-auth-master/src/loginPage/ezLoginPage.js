angular.module('ezweb-auth')
  .directive('ezLoginPage', function(ezUsers, ezScope) {
    /**
     * @ngdoc directive
     * @name ezLoginPage
     * @module ezweb-auth
     * @restrict EA
     * @element div
     * @description
     * Creates a login widget compliant with SG UX guidelines.
     *
     * The widget allows you to create a fully internationalized and fully functionnal login panel.
     *
     * Any content put inside the directive will be added after the "Sign in" button.
     *
     * @param {boolean} usernameIsEmail This is an angular expression.
     * If it evaluates to `true`, the username will validate that the entered login is an e-mail.
     * @param {boolean} sesame This is an angular expression.
     * If it evaluates to `true`, a "sesame" key will be displayed next to the "Sign In" button.
     * @param {string} title The title to display before the login page. This would usually be a welcome text.
     * @param {string} image An image URL to put next to the login information fields
     *
     * @example
     * <example module="loginPageExample">
     * <file name="index.html">
     *   <form ng-controller="LoginPageExampleController as example">
     *     <ez-form-checkbox ng-model="example.email" ez-label="username-is-email"></ez-form-checkbox>
     *     <ez-form-checkbox ng-model="example.sesame" ez-label="sesame"></ez-form-checkbox>
     *     <ez-form-text ng-model="example.title" ez-label="Title"></ez-form-text>
     *     <div ng-if="example.apply">
     *       <ez-login-page username-is-email="example.email"
     *                      sesame="example.sesame"
     *                      title="{{example.title}}">
     *         <span>Additional content</span>
     *       </ez-login-page>
     *     </div>
     *   </form>
     * </file>
     * <file name="controller.js">
     *   angular.module('loginPageExample', ['ezweb-auth'])
     *     .controller('LoginPageExampleController', function($scope, $timeout) {
     *       this.email = false;
     *       this.sesame = false;
     *       this.title = '';
     *       this.apply = true;
     *
     *       var refresh = function() {
     *         this.apply = false;
     *         $timeout(function() {
     *           this.apply = true;
     *         }.bind(this));
     *       }.bind(this);
     *
     *       $scope.$watch(function() {
     *         return this.email;
     *       }.bind(this), refresh);
     *       $scope.$watch(function() {
     *         return this.sesame;
     *       }.bind(this), refresh);
     *       $scope.$watch(function() {
     *         return this.title;
     *       }.bind(this), refresh);
     *     })
     *   ;
     * </file>
     * </example>
     */
    return {
      restrict: 'EA',
      scope: {
        usernameIsEmail: '&',
        stubLogin: '=',
        sesame: '&',
        title: '@',
        image: '@'
      },
      transclude: true,
      templateUrl: './ezLoginPage.html',
      controller: function($scope) {
        $scope.info = {
          username: '',
          password: '',
          rememberme: false
        };

        // noinspection JSUnresolvedVariable
        $scope.supportRememberMe = ezScope.backends.users.hasRememberMe;
        $scope.$watch(function() {
          // noinspection JSUnresolvedVariable
          return ezScope.backends.users.hasRememberMe;
        }, function(newVal) {
          $scope.supportRememberMe = newVal;
        });

        $scope.login = function() {
          delete $scope.error;
          var login = $scope.stubLogin ?
            $scope.stubLogin
            : ezUsers.login;
          login($scope.info.username, $scope.info.password, $scope.info.rememberme)
            .then(function() {
              delete $scope.info;
            }, function(message) {
              $scope.error = message;
            });
        };

        $scope.userPasswordPath = ezUsers.resetPasswordPath();
      }
    };
  })
;
