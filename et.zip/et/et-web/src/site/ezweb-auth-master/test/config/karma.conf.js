// Karma configuration
// http://karma-runner.github.io/0.10/config/configuration-file.html
'use strict';

module.exports = function(karma) {
  var configuration = {
    // base path, that will be used to resolve files and exclude
    // '' means path of karma.conf.js file watch is under Website folder
    // This will be reset to `process.cwd()` by ez-build, so don't bother trying to change it.
    basePath: process.cwd(),

    // karma-jasmine plugin is an Adapter for the Jasmine testing framework.
    frameworks: ['jasmine'],

    // list of files / patterns to load in the browser
    files: [
      // The files are loaded automatically by ez-build.
      // If however you want to add files, anything declared here will be appended after the files defined by the build.
    ],

    exclude: [],

    // IMPORTANT: USE ONLY PhantomJS WHEN COMMIT
    browsers: ['PhantomJS'],

    // JUnit reporter is configured by ez-build. Don't try.

    // ez-build automatically adds 'junit' and 'coverage' if they are not defined here.
    reporters: ['progress'],

    // ez-build configure the folowing preprocessors:
    // - sourcemaps on app files
    // - coverage on client source
    preprocessors: {},

    // Coverage reporter is configured by ez-build. We add HTML and LCOV reporters. You can add some more if you wish.
    coverageReporter: {
      reporters: []
    },

    // web server port
    port: 3050,
    // runner port
    runnerPort: 3051,

    colors: true,

    // level of logging
    // possible values: LOG_DISABLE || LOG_ERROR || LOG_WARN || LOG_INFO || LOG_DEBUG
    // CLI --log-level debug
    logLevel: karma.LOG_INFO,

    // If browser does not capture in given timeout [ms], kill it
    // CLI --capture-timeout 5000
    captureTimeout: 6000,

    // report which specs are slower than 500ms
    // CLI --report-slower-than 500
    reportSlowerThan: 500,

    // ez-build loads the sourcemap, junit and coverage plugins.
    plugins: [
      'karma-jasmine',
      'karma-phantomjs-launcher',
    ]
  };

  karma.set(configuration);
};
