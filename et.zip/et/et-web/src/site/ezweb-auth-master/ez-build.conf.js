'use strict';

module.exports = function(ezBuild) {
  ezBuild.finalBuild.configure('ezweb-auth', {
    assets: 'images/**/*',
    less: '*/*.less',
    css: 'ezweb-auth.min.css',
    client: 'ezweb-auth.min.js',
    rawClient: 'ezweb-auth.js',
    i18n: 'locales/*',
    documentation: 'documentation',
    coverage: 'coverage',
  }, {as: 'ezweb'});
};
