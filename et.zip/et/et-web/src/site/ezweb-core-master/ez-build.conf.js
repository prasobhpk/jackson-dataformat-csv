'use strict';

module.exports = function(ezBuild) {
  ezBuild.finalBuild.configure('ezweb-core', {
    client: 'ezweb-core.min.js',
    rawClient: 'ezweb-core.js',
    css: 'ezweb-core.min.css',
    less: ['*.less', '*/*.less'],
    assets: 'images/**',
    documentation: 'documentation',
    coverage: 'coverage',
  }, {as: 'ezweb'});
};
