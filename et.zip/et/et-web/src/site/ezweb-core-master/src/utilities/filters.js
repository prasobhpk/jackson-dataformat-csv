angular.module('etweb-core')
  .filter('increaseFilter', function () {
    /**
     * @ngdoc filter
     * @name increaseFilter
     * @module etweb-core
     *
     * @description
     * Displays a suitable icon depending on the sign of a number.
     *
     * @param {number} input The number that is going up or down
     * @returns {string} The character that represents the movement.
     * @example
     * <example module="exemple-increase">
     *   <file name="index.html">
     *     <form role="form"
     *           class="form-horizontal"
     *           ng-controller="ExampleIncrease as control">
     *       <et-form-select et-label="Direction"
     *                       et-options="direction as label for (label, direction) in {Up: 1, Down: -1, Stable: 0}"
     *                       ng-model="control.direction"></et-form-select>
     *       This is the result of the filter: {{control.direction | increaseFilter}}.
     *     </form>
     *   </file>
     *   <file name="controller.js">
     *     angular.module('exemple-increase', ['etweb-core'])
     *       .controller('ExampleIncrease', function() {
     *         this.direction = 0;
     *       })
     *     ;
     *   </file>
     * </example>
     */
    return function (input) {
      if (input > 0.0001) {
        return '\u25B2';
      }
      else if (input < -0.0001) {
        return '\u25BC';
      }
      else {
        return '\u2022';
      }
    };
  })
  .filter('characters', function () {
    /**
     * @ngdoc filter
     * @name characters
     * @module etweb-core
     *
     * @description
     * Truncates a text to a maximum number of characters
     *
     * @param {string} input The text to truncate
     * @param {number} chars The maximum number of characters to keep
     * @param {boolean} [breakInWord=false] Whether we cut in the middle of a word (`false`) or
     *      between words (`true`). If there is only one word left in the text, the word will
     *      always be cut in the middle regardless of this parameter.
     * @returns {string} The cut string with an ellipsis (...) at the end.
     *
     * @example
     * <example module="example-characters">
     *   <file name="index.html">
     *     <form role="form" class="form-horizontal" ng-controller="ExampleCharacters as control">
     *       <et-form-checkbox et-label="Break in word"
     *                         ng-model="control.breakInWord"></et-form-checkbox>
     *       <et-form-textarea et-label="Text to break"
     *                         ng-model="control.text"></et-form-textarea>
     *       <et-form-text et-label="Max characters"
     *               et-type="number"
     *               min="0"
     *               ng-model="control.characters">
     *         <et-error key="number">Get us a number !</et-error>
     *       </et-form-text>
     *       This is the result of the filter:
     *       <div>
     *         {{control.text | characters: control.characters : control.breakInWord}}
     *       </div>
     *     </form>
     *   </file>
     *   <file name="controller.js">
     *     angular.module('example-characters', ['etweb-core'])
     *       .controller('ExampleCharacters', function() {
     *         this.breakInWord = false;
     *         this.text = 'Lorem Ipsum Sit Dolor Amet';
     *         this.characters = 20;
     *       })
     *     ;
     *   </file>
     * </example>
     */
    // inspired from https://github.com/sparkalow/angular-truncate
    return function (input, chars, breakInWord) {
      if (isNaN(chars)) {
        return input;
      }
      if (chars <= 0) {
        return '';
      }
      if (input && input.length >= chars) {
        input = input.substring(0, chars);

        if (!breakInWord) {
          var lastspace = input.lastIndexOf(' ');
          // get last space
          if (lastspace !== -1) {
            input = input.substr(0, lastspace);
          }
        }
        else {
          while (input.charAt(input.length - 1) === ' ') {
            input = input.substr(0, input.length - 1);
          }
        }
        return input + '...';
      }
      return input;
    };
  })
  .filter('words', function () {
    /**
     * @ngdoc filter
     * @name words
     * @module etweb-core
     *
     * @description
     * Truncates a text to a maximum number of words
     *
     * @param {string} input The text to truncate
     * @param {number} words The maximum number of words to keep
     * @returns {string} The cut string with an ellipsis (...) at the end.
     * @example
     * <example module="example-words">
     *   <file name="index.html">
     *     <form role="form" class="form-horizontal" ng-controller="ExampleWords as control">
     *       <et-form-textarea et-label="Text to break"
     *                 ng-model="control.text">
     *       </et-form-textarea>
     *       <et-form-text et-label="Max characters"
     *               et-type="number"
     *               min="0"
     *               ng-model="control.words">
     *         <et-error key="number">Get us a number !</et-error>
     *       </et-form-text>
     *       This is the result of the filter:
     *       <div>
     *         {{control.text | words: control.words}}
     *       </div>
     *     </form>
     *   </file>
     *   <file name="controller.js">
     *     angular.module('example-words', ['etweb-core'])
     *       .controller('ExampleWords', function($scope) {
     *         this.text = 'Lorem Ipsum Sit Dolor Amet';
     *         this.words = 3;
     *       })
     *     ;
     *   </file>
     * </example>
     */
    // inspired from https://github.com/sparkalow/angular-truncate
    return function (input, words) {
      if (isNaN(words)) {
        return input;
      }
      if (words <= 0) {
        return '';
      }
      if (input) {
        var inputWords = input.split(/\s+/);
        if (inputWords.length > words) {
          input = inputWords.slice(0, words).join(' ') + '...';
        }
      }
      return input;
    };
  })
;
