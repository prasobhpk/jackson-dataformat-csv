# Changelog

v1.1.2
- Fix non-existent values copy in evaluateAndApply

v1.1.1
- Fix copy by reference issue in evaluateAndApply

v1.1.0
- Initial version from ezweb
