# ezweb-core

Basic utility directives, filters and services that are useful for application development and support the foundation
of most EZWeb functionality.


## Installation

```sh
npm install --save-dev ezweb-core
```

If you do not use `ezweb.start()` (see https://sgithub.fr.world.socgen/CTT-Ezweb/ezweb), you
need to add the `ezweb-core` AngularJS module as a dependency to your app.


## Configuration

ezweb-core is based on EZBuild build system. Its configuration file, `ezbuild.conf.js` is located at the root of the
repository.

It is automatically executed when the EZWeb application is run.


## API documentation

The API documentation is here: https://ezweb.fr.world.socgen/#/api/ezweb-core


## Code coverage

The code coverage is here: https://ezweb.fr.world.socgen/#/testing/coverage/ezweb-core


## How to contribute

### Install library in development mode

If you want to contribute to ezweb-core, you can install it in your application, in development mode.

This way you can update it and test the new behavior directly in your application.

1. Remove the `ezweb-core` folder from `yourApp/node_modules`
2. Fork the SGithub [ezweb-core](https://sgithub.fr.world.socgen/CTT-Ezweb/ezweb-core) repository
3. Clone **YOUR** ezweb-core repository into `yourApp/node_modules`
4. Run `npm install` from `yourApp/node_modules/ezweb-core`
5. Run `gulp serve` from `yourApp/node_modules/ezweb-core`
6. Run `gulp serve` from `yourApp`

Now when you update `yourApp/node_modules/ezweb-core` files, and rerun `gulp serve` from
`yourApp/node_modules/ezweb-core` to build it, your changes should be available in your application.

If not, try stopping and running `gulp serve` again from `yourApp`.

### Contribute

When your new feature is **working**, **documented**, and **successfully tested**, you can ask the EZWeb team to
integrate it into the official [ezweb-core](https://sgithub.fr.world.socgen/CTT-Ezweb/ezweb-core) repository.

1. Commit and push your changes in your forked repository
2. Create a Pull Request on the official ezweb-core repository, and add in the comment field an explanation of your
work.

The EZWeb team will be notified, will check your request, and may decide to integrate the new feature into the
repository.
