'use strict';

var ezBuild = require('ez-angular-lib');

ezBuild.env.publishCoverage = true;
ezBuild.finalBuild.assets.pipeline.src('less', 'src/**/*.less', {base: 'src'});
ezBuild.finalBuild.assets.pipeline.src('images', 'src/images/**', {base: 'src'});

ezBuild.load();
